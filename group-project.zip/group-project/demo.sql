-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2019 at 08:05 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `news_title` varchar(100) NOT NULL,
  `news_description` text NOT NULL,
  `news_image` text NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `news_title`, `news_description`, `news_image`, `status`) VALUES
(8, 'Police, jute mill workers clash in Khulna', 'The three-day countrywide work abstention of workers of different state-owned jute mills ended yesterday amid violence when police and workers clashed in Khulna, leaving 16 people injured.', '../assets/images/jute_mills_worker_unrest_1.jpg', 0),
(9, 'Reforms needed to sustain growth', 'Bangladesh needs to come up with reforms at the earliest to sustain the growth momentum which has landed it among the five fastest growing economies in the world, the World Bank said yesterday.', '../assets/images/fastest_economy.jpg', 1),
(10, 'World Bank chief resigns abruptly', 'World Bank Group President Jim Yong Kim unexpectedly resigned on Monday, more than three years before his term ends in 2022, amid differences with the Trump administration over climate change and the need for more development resources.', '../assets/images/kim-reuters-wb.jpg', 0),
(11, 'Pollution the killer', 'Bangladesh saw around 234,000 deaths, including 80,000 in urban areas, due to environmental pollution and related health risks in 2015, making it one of the worst affected countries in the world, reveals a World Bank report.', '../assets/images/wb-bd-deaths-chart.jpg', 1),
(12, 'Rohingya crisis: A concern for the region', 'Reacting to the insurgent attacks on some police outposts and an army camp on August 25, the Myanmar security forces have unleashed a \"war\" of sorts against the Rohingyaâ€”an ethnic minority group living for centuries in the Rakhine state of Myanmarâ€”burning down their villages, k', '../assets/images/ann_3.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'ferdaus', 'fa@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'admin', 'admin@gmail.com', '25d55ad283aa400af464c76d713c07ad'),
(3, 'asdgads', 'sadmin@gmail.com', '25d55ad283aa400af464c76d713c07ad'),
(4, 'adga', 'admddin@gmail.com', '25d55ad283aa400af464c76d713c07ad'),
(5, 'adsg', 'addddmin@gmail.com', '25d55ad283aa400af464c76d713c07ad'),
(6, 'asdg', 'admidddn@gmail.com', '25d55ad283aa400af464c76d713c07ad');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
