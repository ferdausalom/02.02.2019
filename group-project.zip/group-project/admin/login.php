<?php
session_start();
if (isset($_SESSION['id'])){
    header('Location:index.php');
}

require_once '../vendor/autoload.php';
use App\Classes\Login;
$login = new Login();
$message = '';
if(isset($_POST['btn'])){
  $message = $login->adminLogin($_POST);
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="container" style="margin-top: 300px;">
    <div class="row">
        <div class="col-md-6 m-auto">
            <div class="card">
                <div class="card-title">
                    <h3 class="text-center mt-3 mb-0">Admin Login</h3>
                </div>
                <div class="card-body">
                    <?php
                   $message = $_GET['signupmessage'];
                    ?>
                    <?php if ($message !=''){?>
                    <h4 class="text-center alert alert-danger mt-0"><?php echo $message;?></h4>
                    <?php }?>
                    <form action="" method="POST">
                        <div class="form-group row">
                            <label class="col-form-label col-md-4">Email Address<sup>*</sup></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="email" maxlength="50" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-4">Password<sup>*</sup></label>
                            <div class="col-md-8">
                                <input type="password" class="form-control" maxlength="50" name="password" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="offset-4 col-md-8">
                                <input type="submit" name="btn" class="btn btn-primary btn-block" value="Login">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="offset-4 col-md-8">
                                Don't have an account? <a href="signUp.php">Sign-up</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>