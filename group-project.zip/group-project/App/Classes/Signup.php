<?php
/**
 * Created by PhpStorm.
 * User: Ferdaus
 * Date: 4/3/2019
 * Time: 6:00 PM
 */

namespace App\Classes;


class Signup
{
    public function signUp($data){
        $password = md5($data['password']);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$data[name]','$data[email]','$password')";

        if (mysqli_query(Connection::dbConnection(),$sql)){

            header('Location:../admin/login.php?signupmessage=Signup%20completed%20successfully');

        }else{
            die('Query Problem'.mysqli_error(Connection::dbConnection()));
        }

    }
}