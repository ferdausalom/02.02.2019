<?php
/**
 * Created by PhpStorm.
 * User: Ferdaus
 * Date: 4/3/2019
 * Time: 6:00 PM
 */

namespace App\Classes;


class Signup
{
    public function signUp($data){
        $password = md5($data['password']);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$data[name]','$data[email]','$password')";

        if (mysqli_query(Connection::dbConnection(),$sql)){
            return $message ='Sign up completed Successfully.';

        }else{
            die('Query Problem'.mysqli_error(Connection::dbConnection()));
        }

    }
}