<?php
/**
 * Created by PhpStorm.
 * User: Ferdaus
 * Date: 4/3/2019
 * Time: 6:01 PM
 */

namespace App\Classes;


class Connection
{
    public function dbConnection(){
        $link = mysqli_connect('localhost','root','','demo');
        return $link;
    }
}