<?php

require_once "vendor/autoload.php";
use App\Classes\Student;
$student = new Student();
$message = '';
if (isset($_GET['status'])){
    $id = $_GET['id'];
    $student = new Student();
    $message = $student->deleteStudent($id);
}
$result = $student->viewStudentInfo();
$Message ='';
if (isset($_POST['btn'])){
    $result = $student->searchStudentInfo();
}
?>
<h2><?php echo $message; if( !empty( $_REQUEST['Message'] ) ){echo $_REQUEST['Message'];}?></h2>

<form action="" method="POST">
    <table>
        <tr>
            <td>Searcg:</td>
            <td><input type="text" name="searchtext"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn" value="Search"></td>
        </tr>
    </table>
</form>

<table border="1" width="500">
    <tr>
        <td><a href="admin/addStudent.php">Add</a> </td>
        <td> <a href="viewStudent.php">View</a></td>
    </tr>
    <tr>
        <th>Id</th>
        <th>Name</th>
        <th>Email</th>
        <th>mobile</th>
        <th>Action</th>
    </tr>
    <?php while ($student = mysqli_fetch_assoc($result)){?>
    <tr>
        <td><?php echo $student['id'];?></td>
        <td><?php echo $student['name'];?></td>
        <td><?php echo $student['email'];?></td>
        <td><?php echo $student['mobile'];?></td>
        <td><a href="editStudent.php?id=<?php echo $student['id'];?>">Edit</a> ||
            <a onclick="return confirm('are you sure?');" href="?status=delete&id=<?php echo $student['id'];?>">Delete</a></td>
    </tr>
    <?php }?>
</table>
