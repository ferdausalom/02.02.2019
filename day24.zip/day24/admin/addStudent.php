<?php
session_start();
if ($_SESSION['id']==null){
    header('Location:login.php');
}

require_once "../vendor/autoload.php";
use App\classes\Login;
$login = new Login();

if (isset($_GET['logout'])){
    $login->adminLogout();
}
?>
<html>
<head>

    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
</head>
<body>

<?php include "inc/menu.php"?>

</body>
</html>
<!--<form action="" method="POST">-->
<!--    <table>-->
<!--        <tr>-->
<!--            <td><a href="addStudent.php">Add</a> </td>-->
<!--            <td> <a href="../viewStudent.php">View</a></td>-->
<!--            <td> <a href="?logout=true">Logout</a></td>-->
<!--        </tr>-->
<!--        <tr>-->
<!--            <td>Name:</td>-->
<!--            <td><input type="text" name="name"></td>-->
<!--        </tr>-->
<!--        <tr>-->
<!--            <td>Email:</td>-->
<!--            <td><input type="text" name="email"></td>-->
<!--        </tr>-->
<!--        <tr>N-->
<!--            <td>Mobile:</td>-->
<!--            <td><input type="text" name="mobile"></td>-->
<!--        </tr>-->
<!--        <tr>-->
<!--            <td>Name:</td>-->
<!--            <td><input type="submit" name="btn" value="Submit"></td>-->
<!--        </tr>-->
<!--    </table>-->
<!--</form>-->