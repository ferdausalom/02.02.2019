<?php
session_start();
if ($_SESSION['id']==null){
    header('Location:login.php');
}

require_once "../vendor/autoload.php";
use App\classes\Login;
$login = new Login();

if (isset($_GET['logout'])){
    $login->adminLogout();
}
?>
<html>
<head>

    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
</head>
<body>

<?php include "inc/menu.php"?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                        <tr>
                            <th>SL</th>
                            <th>Title</th>
                            <th>Desc</th>
                            <th>Pub</th>
                            <th>Action</th>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <a href="">Edit</a>
                                <a href="">Delete</a>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../Assets/js/bootstrap.min.js"></script>
</body>
</html>