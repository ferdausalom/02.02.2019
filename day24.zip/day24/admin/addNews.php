<?php
session_start();
if ($_SESSION['id']==null){
    header('Location:login.php');
}

require_once "../vendor/autoload.php";
use App\classes\Login;

$login = new Login();

if (isset($_GET['logout'])){
    $login->adminLogout();
}
use App\classes\News;

$message="";
if (isset($_POST['btn'])){
    $news = new News();
   $message = $news->saveNewsInfo();
}
?>
<html>
<head>

    <link rel="stylesheet" href="../Assets/css/bootstrap.min.css">
</head>
<body>

<?php include "inc/menu.php"?>
<h2><?php echo $message;?></h2>
<form action="" method="POST" enctype="multipart/form-data">
    <table>
        <tr>
            <td>Title</td>
            <td><input type="text" name="news_title"></td>
        </tr>
        <tr>
            <td>Desc:</td>
            <td><textarea name="news_description"></textarea></td>
        </tr>
        <tr>
            <td>Image</td>
            <td><input type="file" name="news_image" accept="image/*"></td>
        </tr>
        <tr>
            <td>Publication</td>
            <td>
                <select class="form-control" name="status">
                    <option>---Select Publication --</option>
                    <option value="1">Published</option>
                    <option value="0">Unpublished</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><input type="submit" name="btn" value="Submit"></td>
        </tr>
    </table>
</form>

<script src="../Assets/js/bootstrap.min.js"></script>
</body>
</html>