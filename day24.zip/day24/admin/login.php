<?php
session_start();
if (isset($_SESSION['id'])){
    header('Location:addStudent.php');
}
 require_once "../vendor/autoload.php";
 use App\classes\Login;
 $login = new Login();
$msg ='';
 if (isset($_POST['btn'])){
    $msg = $login->adminLogin($_POST);

 }

?>
<!DCOTYPE html>
<html>
<head>
    <title>Admin</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
</head>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6 m-auto">
                <div class="card">
                    <div class="card-title">
                        <h2 class="text-danger text-center"><?php echo $msg;?></h2>
                        <h3 class="text-center">Admin Login</h3>
                    </div>
                    <form action="" method="POST">
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-form-label col-md-3">Email</label>
                                <div class="col-md-9">
                                    <input type="text" name="email" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-form-label col-md-3">Password</label>
                                <div class="col-md-9">
                                    <input type="password" name="password" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="offset-3 col-md-9">
                                    <button type="submit" name="btn" class="btn btn-primary btn-block">Login</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
</html>