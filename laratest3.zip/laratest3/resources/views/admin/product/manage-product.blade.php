@extends('admin.master')
@section('body')
    <br/>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h3 id="close-msg" class="text-center text-success">{{Session::get('message')}}</h3>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr class="bg-primary">
                                <th>sl no</th>
                                <th>Cat name</th>
                                <th>Brand name</th>
                                <th>Product name</th>
                                <th>Product image</th>
                                <th>Product price</th>
                                <th>Product Quantity</th>
                                <th>publication stat</th>
                                <th>action</th>
                            </tr>
                            @php($i=1)
                            @foreach($products as $product)
                            <tr class="text-center">
                                <td>{{$i++}}</td>
                                <td>{{$product->category_name}}</td>
                                <td>{{$product->brand_name}}</td>
                                <td>{{$product->product_name}}</td>
                                <td>
                                    <?php $altText = str_replace('product-image/', '', $product->product_image);?>
                                    <img width="100" height="70" src="{{asset($product->product_image)}}" alt="{{$altText}}"/>
                                </td>
                                <td>{{$product->product_price}}</td>
                                <td>{{$product->product_quantity}}</td>
                                <td>{{$product->publication_status}}</td>
                                <td>{{$product->product_name}}</td>
                            @endforeach
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection