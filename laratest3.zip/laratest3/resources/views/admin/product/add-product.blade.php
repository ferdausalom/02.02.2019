@extends('admin.master')
@section('body')
    <br/>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h3 class="text-center text-success">{{Session::get('message')}}</h3>
                    {{ Form::open(['route'=>'new-product','method'=>'POST','class'=>'form-horizontal','enctype'=>'multipart/form-data']) }}

                    <div class="form-group">
                        {{Form::label('category_name', 'Category Name',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            <select class="form-control" name="category_id">
                                <option>--Select Category--</option>
                                @foreach($categories as $category)
                                <option value="{{$category->id}}">{{$category->category_name}}</option>
                                @endforeach
                            </select>
                            <span class="text-center text-danger">{{$errors->has('category_name') ? $errors->first('category_name') : ''}}</span>
                        </div>
                    </div>


                    <div class="form-group">
                        {{Form::label('brand_name', 'Brand Name',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            <select class="form-control" name="brand_id">
                                <option>--Select Brand Name--</option>
                                @foreach($brands as $brand)
                                <option value="{{$brand->id}}">{{$brand->brand_name}}</option>
                                @endforeach
                            </select>
                            <span class="text-center text-danger">{{$errors->has('brand_description') ? $errors->first('brand_description') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('product_name', 'Product Name',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            {{Form::text('product_name',' ',['class'=>'form-control'])}}
                            <span class="text-center text-danger">{{$errors->has('product_name') ? $errors->first('product_name') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('product_price', 'Product Price',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            {{Form::number('product_price',' ',['class'=>'form-control'])}}
                            <span class="text-center text-danger">{{$errors->has('product_price') ? $errors->first('product_price') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('product_quantity', 'Product Quantity',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            {{Form::number('product_quantity',' ',['class'=>'form-control'])}}
                            <span class="text-center text-danger">{{$errors->has('product_quantity') ? $errors->first('product_quantity') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('short_description', 'Short Description',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            {{Form::textarea('short_description',' ',['class'=>'form-control','rows'=>'3'])}}
                            <span class="text-center text-danger">{{$errors->has('short_description') ? $errors->first('short_description') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('long_description', 'Long Description',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            {{Form::textarea('long_description',' ',['class'=>'form-control','rows'=>'4','id'=>'editor'])}}
                            <span class="text-center text-danger">{{$errors->has('long_description') ? $errors->first('long_description') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        {{Form::label('product_image', 'Product Image',['class' => 'col-md-3'])}}
                        <div class="col-md-9">
                            <input type="file" name="product_image" accept="image/*">
                            <span class="text-center text-danger">{{$errors->has('product_image') ? $errors->first('product_image') : ''}}</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-3">Publication Status</label>
                        <div class="col-md-9 radio">
                            <label><input type="radio" name="publication_status" value="1" /> Published </label>
                            <label> <input type="radio" name="publication_status" value="0" /> Unublished </label><br/>
                            <span class="text-center text-danger">{{$errors->has('publication_status') ? $errors->first('publication_status') : ''}}</span>

                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-9 col-md-offset-3">
                            <input type="submit" name="btn" value="Save Product Info" class="btn btn-success btn-block"/>
                        </div>
                    </div>

                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>

@endsection