<?php

Route::get('/', [
    'uses'  =>  'NewShopController@index',
    'as'    =>  '/'
]);

Route::get('/category-product/{id}', [
    'uses'  =>  'NewShopController@categoryProduct',
    'as'    =>  'category-product'
]);



Route::get('/category/add', [
    'uses'  =>  'CategoryController@index',
    'as'    =>  'add-category'
]);

Route::post('/category/save', [
    'uses'  =>  'CategoryController@saveCategoryInfo',
    'as'    =>  'new-category'
]);

Route::get('/category/manage',[
   'uses' => 'CategoryController@manageCategoryInfo',
   'as'   => 'manage-category'
]);

Route::get('/category/unpublished/{id}',[
    'uses' => 'CategoryController@unpublishedCategoryInfo',
    'as'   => 'unpublished-category'
]);

Route::get('/category/published/{id}',[
    'uses' => 'CategoryController@publishedCategoryInfo',
    'as'   => 'published-category'
]);

Route::get('/category/edit/{id}',[
   'uses' => 'CategoryController@editCategoryInfo',
   'as'   => 'edit-category'
]);

Route::post('/category/update',[
    'uses' => 'CategoryController@updateCategoryInfo',
    'as'   =>'update-category'
]);

Route::get('/category/delete/{id}',[
    'uses' => 'CategoryController@deleteCategoryInfo',
    'as'   =>'delete-category'
]);

Route::get('/brand/add',[
    'uses' =>'BrandController@index',
    'as'   =>'add-brand'
]);

Route::post('/brand/save',[
    'uses' =>'BrandController@saveBrand',
    'as'   =>'new-brand'
]);

Route::get('/product/add',[
   'uses' =>'ProductController@index',
   'as'   =>'add-product'
]);

Route::post('/product/save',[
   'uses' =>'ProductController@saveProduct',
   'as'   =>'new-product'
]);

Route::get('/product/manage',[
   'uses' =>'ProductController@manageProduct',
   'as'   =>'manage-product'
]);








Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');
