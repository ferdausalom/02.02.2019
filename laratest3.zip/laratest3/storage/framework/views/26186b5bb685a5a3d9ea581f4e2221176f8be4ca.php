<?php $__env->startSection('body'); ?>
    <br/>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h3 id="close-msg" class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr class="bg-primary">
                                <th>sl no</th>
                                <th>Cat name</th>
                                <th>Brand name</th>
                                <th>Product name</th>
                                <th>Product image</th>
                                <th>Product price</th>
                                <th>Product Quantity</th>
                                <th>publication stat</th>
                                <th>action</th>
                            </tr>
                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->brand_name); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td>
                                    <?php $altText = str_replace('product-image/', '', $product->product_image);?>
                                    <img width="100" height="70" src="<?php echo e(asset($product->product_image)); ?>" alt="<?php echo e($altText); ?>"/>
                                </td>
                                <td><?php echo e($product->product_price); ?></td>
                                <td><?php echo e($product->product_quantity); ?></td>
                                <td><?php echo e($product->publication_status); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>