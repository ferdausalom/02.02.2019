<?php
session_start();

require_once "../vendor/autoload.php";
use App\classes\Login;
$login = new Login();

if (isset($_GET['logout'])){
    $login->adminLogout();
}
?>
<h1><?php echo $_SESSION['name'];?></h1>
<form action="" method="POST">
    <table>
        <tr>
            <td><a href="addStudent.php">Add</a> </td>
            <td> <a href="../viewStudent.php">View</a></td>
            <td> <a href="?logout=true">Logout</a></td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>Mobile:</td>
            <td><input type="text" name="mobile"></td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><input type="submit" name="btn" value="Submit"></td>
        </tr>
    </table>
</form>