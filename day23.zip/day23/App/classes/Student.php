<?php
/**
 * Created by PhpStorm.
 * User: Web App Develop - PH
 * Date: 3/18/2019
 * Time: 9:57 AM
 */

namespace App\Classes;


class Student
{
    public function saveStudentInfo(){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "INSERT INTO demos(name, email, mobile) VALUES ('$_POST[name]','$_POST[email]','$_POST[mobile]')";

        if (mysqli_query($link,$sql)){
            $message = "S info saved";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }

    public function viewStudentInfo(){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "SELECT * FROM demos";
        if (mysqli_query($link,$sql)){
            $result = mysqli_query($link,$sql);
            return $result;
            $message = "S info saved";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }

    public function editStudentInfo($id){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "SELECT * FROM demos WHERE id= '$id'";

        if (mysqli_query($link,$sql)){
            $result = mysqli_query($link,$sql);
            return $result;
            $message = "S info edited";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }

    public function updateStudentInfo($id){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "UPDATE demos SET name='$_POST[name]', email='$_POST[email]', mobile='$_POST[mobile]' WHERE id='$id'";

        if (mysqli_query($link, $sql)){

            header('Location:viewStudent.php?Message=updated');
        }
        else{
            die('problem'.mysqli_error($link));
        }
    }

    public function deleteStudent($id){
        $link = mysqli_connect('localhost','root','','demo');
        $sql = "DELETE FROM demos WHERE id='$id'";

        if (mysqli_query($link, $sql)){
            $message = "deleted";
            return $message;
        }
        else{
            die('problem'.mysqli_error($link));
        }
    }

    public function searchStudentInfo(){
        $link = mysqli_connect('localhost','root','','demo');
        $sql = "SELECT * FROM demos WHERE name LIKE '$_POST[searchtext]%'";

        if (mysqli_query($link, $sql)){
            $result = mysqli_query($link, $sql);
            return $result;
        }
        else{
            die('problem'.mysqli_error($link));
        }
    }
}