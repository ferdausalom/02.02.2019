-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2019 at 01:45 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yourfurniture`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(10, 'Hatil', 'Hatil Furniture', 1, '2019-04-14 10:51:21', '2019-04-14 10:51:21'),
(11, 'Navana', 'Navana Furniture', 1, '2019-04-14 10:51:34', '2019-04-14 10:51:34'),
(12, 'Otobi', 'Otobi Furniture', 1, '2019-04-14 10:51:43', '2019-04-14 10:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `publication_status`, `created_at`, `updated_at`) VALUES
(4, 'Chair', 'Chair Furniture', 1, '2019-04-14 10:50:10', '2019-04-14 10:51:59'),
(5, 'Table', 'Table Furniture', 1, '2019-04-14 10:50:27', '2019-04-14 10:52:12'),
(6, 'Khat', 'Khat Furniture', 0, '2019-04-14 10:50:56', '2019-04-15 17:45:22');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipCode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `email`, `password`, `country`, `street_address`, `city`, `zipCode`, `comment`, `created_at`, `updated_at`) VALUES
(1, 'fadfgaas', 'asdgasdg', 'a@gmail.com', '$2y$10$Fxzxa2bGpa6YE07YXp5YnOnVjYX3HQE4o9b7fGouhpD3o91akprwa', 'uk', 'asdg', 'asdg', 'asdg', 'adsga', '2019-04-17 09:54:36', '2019-04-17 09:54:36'),
(3, 'fadfgaas', 'asdgasdg', 'sa@gmail.com', '$2y$10$PNnVnKWEwLTmoNE3xYRx2.upsRQsY8XT6/.jLmDOlH3vFGceNq3GO', 'uk', 'asdg', 'adg', 'asgd', 'asg', '2019-04-17 09:59:46', '2019-04-17 09:59:46'),
(10, 'ferdaus', 'alom', 'faferdaus@gmail.com', '$2y$10$Hd36axOLkZt/1h0ZpADvieNuGUdYhblyS2LQ2aGKeQAi9lGeX7L6G', 'uk', 'dhaka', 'azimpur', '1205', 'asdg', '2019-04-17 10:38:57', '2019-04-17 10:38:57'),
(14, 'testmail', 'testt', 'alomferdaus@gmail.com', '$2y$10$NImXZBVsW5ZxJIyYBcuAsue1v973Hkn4/AgikoL18ixfkPOvSALSm', 'ger', 'adsg', 'asdg', 'asdg', 'asdgasd', '2019-04-17 10:54:26', '2019-04-17 10:54:26'),
(15, 'fadfgaas', 'alom', 'as@gmail.com', '$2y$10$CCh7juEM5lGU2KB4zfaJfu.IcL2pvk2dAMaj4nOSa./3nHw1rs0D2', 'ger', 'asdg', 'azimpur', '1205', 'asdgasdg', '2019-04-17 22:58:39', '2019-04-17 22:58:39'),
(16, 'fadfgaas', 'asdgasdg', 'aaa@gmail.com', '$2y$10$q3gtSwT.LIkWxyGuZebwsOsGQ6v6eqW6ZUvu1npwXbHs0DVQhLnv6', 'ger', 'dhaka', 'azimpur', '1205', 'arsfga', '2019-04-18 05:45:48', '2019-04-18 05:45:48'),
(17, 'aaaa', 'asdgasdg', 'aacca@gmail.com', '$2y$10$BN.pqD2OAx4h0lQu5aGTl.nrK0dyZh63HVPNYPFhNjhtfMIP7mmOm', 'fra', 'dhaka', 'azimpur', '1205', 'adga', '2019-04-18 09:45:53', '2019-04-18 09:45:53');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_04_09_015140_create_categories_table', 1),
(4, '2019_04_10_130149_create_brands_table', 1),
(5, '2019_04_13_152554_create_products_table', 2),
(6, '2019_04_17_120307_create_customers_table', 3),
(7, '2019_04_17_155238_create_customers_table', 4),
(8, '2019_04_18_060055_create_shippings_table', 5),
(9, '2019_04_18_075316_create_orders_table', 6),
(10, '2019_04_18_075504_create_payments_table', 6),
(11, '2019_04_18_075522_create_order_details_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `shipping_id` int(11) NOT NULL,
  `order_total` int(11) NOT NULL,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `shipping_id`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 16, 6, 20, 'Pending', '2019-04-18 06:12:27', '2019-04-18 06:12:27'),
(2, 16, 7, 20, 'Pending', '2019-04-18 06:12:45', '2019-04-18 06:12:45'),
(3, 16, 8, 20, 'Pending', '2019-04-18 06:13:02', '2019-04-18 06:13:02'),
(4, 16, 9, 40, 'Pending', '2019-04-18 06:15:12', '2019-04-18 06:15:12'),
(5, 16, 10, 11, 'Pending', '2019-04-18 06:15:42', '2019-04-18 06:15:42'),
(6, 16, 13, 31, 'Pending', '2019-04-18 06:24:16', '2019-04-18 06:24:16'),
(7, 16, 14, 15, 'Pending', '2019-04-18 06:24:57', '2019-04-18 06:24:57'),
(8, 16, 15, 35, 'Pending', '2019-04-18 07:44:37', '2019-04-18 07:44:37'),
(9, 16, 16, 35, 'Pending', '2019-04-18 07:59:14', '2019-04-18 07:59:14'),
(10, 16, 17, 35, 'Pending', '2019-04-18 08:07:55', '2019-04-18 08:07:55'),
(11, 16, 17, 35, 'Pending', '2019-04-18 08:09:02', '2019-04-18 08:09:02'),
(12, 16, 18, 35, 'Pending', '2019-04-18 08:11:53', '2019-04-18 08:11:53'),
(13, 16, 18, 35, 'Pending', '2019-04-18 08:12:11', '2019-04-18 08:12:11'),
(14, 16, 20, 35, 'Pending', '2019-04-18 08:15:44', '2019-04-18 08:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_quantity`, `created_at`, `updated_at`) VALUES
(1, 11, 18, 'Nice Table', 15.00, 1, '2019-04-18 08:09:02', '2019-04-18 08:09:02');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_type` int(11) NOT NULL,
  `order_total` int(11) NOT NULL,
  `order_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `order_id`, `payment_type`, `order_total`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 10, 0, 0, 'Pending', '2019-04-18 08:07:55', '2019-04-18 08:07:55'),
(2, 11, 0, 0, 'Pending', '2019-04-18 08:09:02', '2019-04-18 08:09:02'),
(3, 13, 0, 0, 'Pending', '2019-04-18 08:12:11', '2019-04-18 08:12:11'),
(4, 14, 0, 0, 'Pending', '2019-04-18 08:15:44', '2019-04-18 08:15:44');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `product_price` double(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `category_id`, `brand_id`, `product_price`, `product_quantity`, `short_description`, `long_description`, `product_image`, `publication_status`, `created_at`, `updated_at`) VALUES
(15, 'Nice Chair', 4, 12, 10.00, 10, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/NiceChair.jpg', 1, '2019-04-14 10:57:45', '2019-04-16 02:10:40'),
(16, 'Small Chair', 4, 11, 12.00, 15, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/SmallChair.jpg', 1, '2019-04-14 11:06:05', '2019-04-15 09:46:23'),
(17, 'Medium Chair', 4, 10, 11.00, 20, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/MediumChair.jpg', 1, '2019-04-14 11:07:05', '2019-04-14 11:07:05'),
(18, 'Nice Table', 5, 10, 15.00, 30, 'Our signature series collection of conference room furniture is just what you are looking for. Clean, contemporary styling and rich laminate finish adorn your office or conference room the professional look you seek.', '<p>Our signature series collection of conference room furniture is just what you are looking for. Clean, contemporary styling and rich laminate finish adorn your office or conference room the professional look you seek.</p>', 'product-image/NiceTable.jpg', 1, '2019-04-14 11:09:58', '2019-04-14 11:09:58'),
(19, 'Nice Chair', 4, 11, 11.00, 50, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/NiceChair.jpg', 1, '2019-04-14 11:11:13', '2019-04-14 11:11:13'),
(20, 'Flexible Chair', 4, 12, 9.00, 30, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/FlexibleChair.jpg', 1, '2019-04-14 11:12:01', '2019-04-14 11:12:01'),
(22, 'Table', 5, 11, 20.00, 10, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/Table.jpg', 1, '2019-04-14 11:12:42', '2019-04-14 11:12:42'),
(23, 'Chair', 4, 10, 20.00, 10, 'Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.', '<p>Our slim and light weight folding chairs are ideal for quick setups for events and functions or even a family gathering for a feast. Folds in and out in an absolute noise free manner and takes minimal space to store up.</p>', 'product-image/SmallChair.jpg', 1, '2019-04-14 11:13:31', '2019-04-14 11:13:31'),
(24, 'Medium Chair', 4, 11, 20.00, 10, 'Our signature series collection of conference room furniture is just what you are looking for. Clean, contemporary styling and rich laminate finish adorn your office or conference room the professional look you seek.', '<p>Our signature series collection of conference room furniture is just what you are looking for. Clean, contemporary styling and rich laminate finish adorn your office or conference room the professional look you seek.</p>', 'product-image/MediumChair.jpg', 1, '2019-04-14 11:17:51', '2019-04-14 11:17:51');

-- --------------------------------------------------------

--
-- Table structure for table `shippings`
--

CREATE TABLE `shippings` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zipCode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shippings`
--

INSERT INTO `shippings` (`id`, `full_name`, `email_address`, `country`, `street_address`, `city`, `zipCode`, `phone_number`, `created_at`, `updated_at`) VALUES
(1, 'fadfgaas', 'as@gmail.com', 'ger', 'adgag', 'azimpur', '1205', '90690', '2019-04-18 00:16:21', '2019-04-18 00:16:21'),
(2, 'fadfgaas', 'aaa@gmail.com', 'ger', 'asdgadg', 'azimpur', '1205', '424', '2019-04-18 06:06:14', '2019-04-18 06:06:14'),
(3, 'fadfgaas', 'aaa@gmail.com', 'ger', 'asdgadg', 'azimpur', '1205', '424', '2019-04-18 06:07:42', '2019-04-18 06:07:42'),
(4, 'fadfgaas', 'aaa@gmail.com', 'ger', 'sfh', 'azimpur', '1205', '45345', '2019-04-18 06:07:56', '2019-04-18 06:07:56'),
(5, 'fadfgaas', 'aaa@gmail.com', 'ger', 'fdh', 'azimpur', '1205', '42543', '2019-04-18 06:09:30', '2019-04-18 06:09:30'),
(6, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dfgj', 'azimpur', '1205', '24532', '2019-04-18 06:12:00', '2019-04-18 06:12:00'),
(7, 'fadfgaas', 'aaa@gmail.com', 'ger', 'sdfgh', 'azimpur', '1205', '46', '2019-04-18 06:12:40', '2019-04-18 06:12:40'),
(8, 'fadfgaas', 'aaa@gmail.com', 'ger', 'fghkfh', 'azimpur', '1205', '43253', '2019-04-18 06:12:58', '2019-04-18 06:12:58'),
(9, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dhaka', 'azimpur', '1205', '445', '2019-04-18 06:15:08', '2019-04-18 06:15:08'),
(10, 'fadfgaas', 'aaa@gmail.com', 'ger', 'fhsdh', 'azimpur', '1205', '5554', '2019-04-18 06:15:39', '2019-04-18 06:15:39'),
(11, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dhaka', 'azimpur', '1205', '5544', '2019-04-18 06:18:55', '2019-04-18 06:18:55'),
(12, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dhaka', 'azimpur', '1205', '5555', '2019-04-18 06:22:38', '2019-04-18 06:22:38'),
(13, 'fadfgaas', 'aaa@gmail.com', 'ger', 'fghkf', 'azimpur', '1205', '555', '2019-04-18 06:24:12', '2019-04-18 06:24:12'),
(14, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dhaka', 'azimpur', '1205', '444', '2019-04-18 06:24:47', '2019-04-18 06:24:47'),
(15, 'fadfgaas', 'aaa@gmail.com', 'ger', 'asdg', 'azimpur', '1205', '555', '2019-04-18 07:44:34', '2019-04-18 07:44:34'),
(16, 'fadfgaas', 'aaa@gmail.com', 'ger', 'asdg', 'azimpur', '1205', '444', '2019-04-18 07:59:11', '2019-04-18 07:59:11'),
(17, 'fadfgaas', 'aaa@gmail.com', 'ger', 'sdfh', 'azimpur', '1205', '4444', '2019-04-18 08:07:52', '2019-04-18 08:07:52'),
(18, 'fadfgaas', 'aaa@gmail.com', 'ger', 'sdgfhs', 'azimpur', '1205', '4444', '2019-04-18 08:11:50', '2019-04-18 08:11:50'),
(19, 'fadfgaas', 'aaa@gmail.com', 'ger', 'asg', 'azimpur', '1205', '4444', '2019-04-18 08:13:20', '2019-04-18 08:13:20'),
(20, 'fadfgaas', 'aaa@gmail.com', 'ger', 'dafhsdf', 'azimpur', '1205', '5555', '2019-04-18 08:15:40', '2019-04-18 08:15:40'),
(21, 'fadfgaas', 'aaa@gmail.com', 'ger', 'hhh', 'azimpur', '1205', '777', '2019-04-18 08:22:46', '2019-04-18 08:22:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ferdaus', 'a@gmail.com', '$2y$10$UjbWkBKhNgEKPBLOBzS6iud9DFPtW8Ih31Dg7KFkiCTAq1TKdqV1q', '1qeIc70Ko5PrnXYUorKo05KgK0802j8jjuxhVln9CSI7qA6SUMBK514j3jay', '2019-04-12 09:53:19', '2019-04-12 09:53:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customers_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shippings`
--
ALTER TABLE `shippings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `shippings`
--
ALTER TABLE `shippings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
