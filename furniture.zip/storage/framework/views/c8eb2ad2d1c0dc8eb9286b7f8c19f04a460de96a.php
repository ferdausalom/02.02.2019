<?php $__env->startSection('title','Product Details'); ?>
<?php $__env->startSection('body'); ?>
    <!-- Product Details Area Start -->
    <div class="single-product-area section-padding-100 clearfix">
        <div class="container-fluid">
            <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mt-50">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('my-shop')); ?>">SHOP</a></li>
                            <li class="breadcrumb-item"><a href="#">Category Name</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($productDetail->product_name); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-7">
                    <div class="single_product_thumb">
                        <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="<?php echo e(asset($productDetail->product_image)); ?>" alt="First slide">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="single_product_desc">
                        <!-- Product Meta Data -->
                        <div class="product-meta-data">
                            <div class="line"></div>
                            <p class="product-price">$<?php echo e($productDetail->product_price); ?></p>
                            <h4><?php echo e($productDetail->product_name); ?></h4>
                            <!-- Ratings & Review -->
                            <div class="ratings-review mb-15 d-flex align-items-center justify-content-between">
                                <div class="ratings">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </div>
                                <div class="review">
                                    <a href="#">Write A Review</a>
                                </div>
                            </div>
                            <!-- Avaiable -->
                            <p class="avaibility"><i class="fa fa-circle"></i> <?php echo e($productDetail->publication_status == 1 ? 'In Stock':'Out of Stock'); ?></p>
                        </div>

                        <div class="short_overview my-5">
                            <?php echo e($productDetail->long_description); ?>

                        </div>

                        <!-- Add to Cart Form -->
                        <?php echo e(Form::open(['route'=>'add-to-cart','class'=>'cart clearfix'])); ?>

                            <div class="cart-btn d-flex mb-50">
                                <p>Qty</p>
                                <div class="quantity">
                                    <input type="number" class="qty-text" min="1" name="qty" value="1">
                                    <input type="hidden" name="id" value="<?php echo e($productDetail->id); ?>"/>
                                </div>
                            </div>
                             <input type="submit" name="btn" class="btn amado-btn" value="Add to cart"/>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- Product Details Area End -->
</div>
<!-- ##### Main Content Wrapper End ##### -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>