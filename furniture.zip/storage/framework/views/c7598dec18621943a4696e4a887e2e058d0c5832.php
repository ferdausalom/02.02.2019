<?php $__env->startSection('title','Profile'); ?>
<?php $__env->startSection('body'); ?>
    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="checkout_details_area mt-30 clearfix">
                        <div class="cart-title">
                            <h3>Your Profile:</h3>
                            <h5>If you want you can change your information.</h5>
                            <hr/>
                        </div>
                        <?php echo e(Form::open()); ?>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <?php echo e(Form::text('first_name',"{$customer->first_name}",['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'First Name','required'])); ?>

                            </div>
                            <div class="col-md-6 mb-3">
                                <?php echo e(Form::text('last_name','',['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'Last Name','required'])); ?>

                            </div>
                            <div class="col-md-6 mb-3">
                                <?php echo e(Form::email('email','',['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])); ?>

                            </div>
                            <div class="col-md-6 mb-3">
                                <?php echo e(Form::password('password',['class'=>'form-control','minlength'=>'8','maxlength'=>'40','placeholder'=>'Password','required'])); ?>

                            </div>
                            <div class="col-12 mb-3">
                                <select class="w-100" name="country">
                                    <option value="usa">--Country--</option>
                                    <option value="uk">United Kingdom</option>
                                    <option value="ger">Germany</option>
                                    <option value="fra">France</option>
                                    <option value="ind">India</option>
                                    <option value="aus">Australia</option>
                                    <option value="bra">Brazil</option>
                                    <option value="cana">Canada</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                <?php echo e(Form::text('street_address','',['class'=>'form-control','placeholder'=>'Address','required'])); ?>

                            </div>
                            <div class="col-12 mb-3">
                                <?php echo e(Form::text('city','',['class'=>'form-control','placeholder'=>'Town','required'])); ?>

                            </div>
                            <div class="col-md-6 mb-3">
                                <?php echo e(Form::text('zipCode','',['class'=>'form-control','placeholder'=>'Zip Code','required'])); ?>

                            </div>
                            <div class="col-md-6 mb-3">
                                <input type="number" class="form-control" name="phone_number" min="0" placeholder="Phone No" required value="">
                            </div>
                            <div class="col-12 mb-3">
                                <?php echo e(Form::textarea('comment','',['class'=>'form-control w-100','cols'=>'30','rows'=>'10','placeholder'=>'Leave a comment about your order','required'])); ?>

                            </div>

                            <div class="col-12 mb-3">
                                <input type="submit" name="btn" class="btn btn-success w-25" value="Save Changes">
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>