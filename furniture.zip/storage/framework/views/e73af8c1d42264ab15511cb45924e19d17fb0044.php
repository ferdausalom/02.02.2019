<h2><?php echo e($first_name.' '.$last_name); ?></h2>
<p>Thanks for join <br/>
Your  Email: <?php echo e($email); ?>

</p>

<p>FurniTure</p>