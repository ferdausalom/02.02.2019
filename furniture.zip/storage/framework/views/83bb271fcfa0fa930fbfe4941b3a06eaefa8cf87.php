<?php $__env->startSection('title','Edit Category'); ?>
<?php $__env->startSection('body'); ?>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-6" style="margin-top: 20px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">Edit Category</h4>
                        <?php if(session('message')): ?>
                            <h4 class="text-center text-success"> <?php echo e(session('message')); ?></h4>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form action="<?php echo e(route('update-category-info')); ?>" method="POST" role="form">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label>Name</label>
                                        <input class="form-control" type="text" name="category_name" value="<?php echo e($category->category_name); ?>" required />
                                        <input class="form-control" type="hidden" name="category_id" value="<?php echo e($category->id); ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea class="form-control" name="category_description" rows="3" required><?php echo e($category->category_description); ?>

                                        </textarea>
                                    </div>
                                    <div class="form-group" >
                                        <label class="col-md-12">Publication Status</label>
                                        <label class="col-md-12"><input type="radio" <?php echo e($category->publication_status==1?'checked':''); ?> name="publication_status" value="1" /> Published</label>
                                        <label class="col-md-12" style="margin-bottom: 20px;"><input type="radio" name="publication_status" <?php echo e($category->publication_status==0?'checked':''); ?> value="0" /> Unublished</label>
                                    </div>
                                    
                                    
                                    
                                    
                                    <input type="submit" name="btn" class="btn btn-success" value="Update Category Info">
                                </form>
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>