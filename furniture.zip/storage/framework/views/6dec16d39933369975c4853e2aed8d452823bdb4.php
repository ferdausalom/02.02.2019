<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo e(asset('')); ?>admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>admin/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo e(asset('')); ?>admin/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="<?php echo e(asset('')); ?>admin/css/sb-admin.css" rel="stylesheet">
    <script src="<?php echo e(asset('')); ?>admin/ckeditor/ckeditor.js"></script>
    <script src="<?php echo e(asset('')); ?>admin/ckeditor/samples/js/sample.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>admin/ckeditor/samples/css/samples.css">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>admin/ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
</head>
<body>
<div id="wrapper">
    <?php echo $__env->make('admin.inc.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('body'); ?>
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<?php echo $__env->make('admin.inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
