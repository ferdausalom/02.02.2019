<?php $__env->startSection('title','Home'); ?>
<?php $__env->startSection('body'); ?>
    <div class="products-catagories-area clearfix">
        <div class="amado-pro-catagory clearfix">
            <!-- Single Catagory -->
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single-products-catagory clearfix">
                <a href="<?php echo e(route('details-product',['id'=>$product->id, 'name'=>$product->product_name])); ?>">
                    <img src="<?php echo e(asset('')); ?><?php echo e($product->product_image); ?>" alt="<?php echo e($product->product_name); ?>" />
                    <!-- Hover Content -->
                    <div class="hover-content">
                        <div class="line"></div>
                        <p>Price $<?php echo e($product->product_price); ?></p>
                        <h4><?php echo e($product->product_name); ?></h4>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>