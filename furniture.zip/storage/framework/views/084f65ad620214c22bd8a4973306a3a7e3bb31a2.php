<?php $__env->startSection('title','All Product'); ?>
<?php $__env->startSection('body'); ?>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12" style="margin-top: 85px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">All Product</h4>
                        <?php if(session('message')): ?>
                            <h4 class="text-center text-success"> <?php echo e(session('message')); ?></h4>
                        <?php endif; ?>
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-responsive table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Product Name</th>
                                    <th>Category Name</th>
                                    <th>Brand Name</th>
                                    <th>Product Price</th>
                                    <th>Product Quantity</th>
                                    <th>Product Short Description</th>
                                    <th>Product Image</th>
                                    <th>Product Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i=1); ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->category_name); ?></td>
                                        <td><?php echo e($product->brand_name); ?></td>
                                        <td>$<?php echo e($product->product_price); ?></td>
                                        <td><?php echo e($product->product_quantity); ?></td>
                                        <td width="30%"><?php echo e($product->short_description); ?></td>
                                        <td><img width="50" height="50" src="<?php echo e(asset($product->product_image)); ?>"/></td>
                                        <td><?php echo e($product->publication_status==1?'published':'Unpublished'); ?></td>
                                        <td width="5%">
                                            <?php if($product->publication_status==1): ?>
                                                <a style="margin-bottom: 8px;" href="<?php echo e(route('unpublished-product',['id'=>$product->id])); ?>" class="btn btn-info">
                                                    <span class="glyphicon glyphicon-arrow-up"></span>
                                                </a>
                                            <?php else: ?>
                                                <a style="margin-bottom: 8px;" href="<?php echo e(route('publish-product',['id'=>$product->id])); ?>" class="btn btn-warning">
                                                    <span class="glyphicon glyphicon-arrow-down"></span>
                                                </a>
                                            <?php endif; ?>
                                            <a style="margin-bottom: 8px;" href="<?php echo e(route('edit-product',['id'=>$product->id])); ?>" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-edit"></span>
                                            </a>
                                            <a onclick="return confirm('are you sure to delete?')" href="<?php echo e(route('product-delete',['id'=>$product->id])); ?>" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.row -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>