
<!-- Core Scripts - Include with every page -->
<script src="<?php echo e(asset('')); ?>admin/js/jquery-1.10.2.js"></script>
<script src="<?php echo e(asset('')); ?>admin/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('')); ?>admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<!-- Page-Level Plugin Scripts - Tables -->
<script src="<?php echo e(asset('')); ?>admin/js/plugins/dataTables/jquery.dataTables.js"></script>
<script src="<?php echo e(asset('')); ?>admin/js/plugins/dataTables/dataTables.bootstrap.js"></script>
<!-- SB Admin Scripts - Include with every page -->
<script src="<?php echo e(asset('')); ?>admin/js/sb-admin.js"></script>
<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script>
    $(document).ready(function() {
        $('#dataTables-example').dataTable();
    });
</script>
<script>
    initSample();
</script>
</body>
</html>