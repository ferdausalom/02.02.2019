<?php $__env->startSection('title','Add Category'); ?>
<?php $__env->startSection('body'); ?>
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-6" style="margin-top: 20px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                       <h4 class="text-center">Add Category</h4>
                        <?php if(session('message')): ?>
                        <h4 class="text-center text-success"> <?php echo e(session('message')); ?></h4>
                        <?php endif; ?>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <?php echo e(Form::open(['route'=>'new-category','role'=>'form'])); ?>

                                
                                    <div class="form-group">
                                        <label>Name</label>
                                        <?php echo e(Form::text('category_name','',['class'=>'form-control','placeholder'=>'Category Name','required'])); ?>

                                        
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>

                                        <textarea class="form-control" name="category_description" placeholder="Category Description" rows="3" required></textarea>
                                    </div>
                                    <div class="form-group" >
                                        <label class="col-md-12">Publication Status</label>
                                        <label class="col-md-12"><input type="radio" checked name="publication_status" value="1" /> Published</label>
                                        <label class="col-md-12" style="margin-bottom: 20px;"><input type="radio" name="publication_status" value="0" /> Unublished</label>
                                    </div>
                                    
                                        
                                        
                                    
                                    <input type="submit" name="btn" class="btn btn-success" value="Save Category Info"> &nbsp;&nbsp;
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                <?php echo e(Form::close()); ?>

                            </div>
                            <!-- /.col-lg-6 (nested) -->
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>