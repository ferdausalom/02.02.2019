@extends('front-end.master')
@section('title','Product Details')
@section('body')
    <!-- Product Details Area Start -->
    <div class="single-product-area section-padding-100 clearfix">
        <div class="container-fluid">
            @foreach($productDetails as $productDetail)
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mt-50">
                            <li class="breadcrumb-item"><a href="{{route('my-shop')}}">SHOP</a></li>
                            <li class="breadcrumb-item"><a href="#">Category Name</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{$productDetail->product_name}}</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-7">
                    <div class="single_product_thumb">
                        <div id="product_details_slider" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="{{asset($productDetail->product_image)}}" alt="First slide">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="single_product_desc">
                        <!-- Product Meta Data -->
                        <div class="product-meta-data">
                            <div class="line"></div>
                            <p class="product-price">${{$productDetail->product_price}}</p>
                            <h4>{{$productDetail->product_name}}</h4>
                            <!-- Ratings & Review -->
                            <div class="ratings-review mb-15 d-flex align-items-center justify-content-between">
                                <div class="ratings">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </div>
                                <div class="review">
                                    <a href="#">Write A Review</a>
                                </div>
                            </div>
                            <!-- Avaiable -->
                            <p class="avaibility"><i class="fa fa-circle"></i> {{$productDetail->publication_status == 1 ? 'In Stock':'Out of Stock'}}</p>
                        </div>

                        <div class="short_overview my-5">
                            {{$productDetail->long_description}}
                        </div>

                        <!-- Add to Cart Form -->
                        {{Form::open(['route'=>'add-to-cart','class'=>'cart clearfix'])}}
                            <div class="cart-btn d-flex mb-50">
                                <p>Qty</p>
                                <div class="quantity">
                                    <input type="number" class="qty-text" min="1" name="qty" value="1">
                                    <input type="hidden" name="id" value="{{$productDetail->id}}"/>
                                </div>
                            </div>
                             <input type="submit" name="btn" class="btn amado-btn" value="Add to cart"/>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    <!-- Product Details Area End -->
</div>
<!-- ##### Main Content Wrapper End ##### -->
@endsection