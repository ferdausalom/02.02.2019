@extends('front-end.master')
@section('title','Register')
@section('body')
    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="checkout_details_area mt-30 clearfix">
                        <div class="cart-title">
                            <h2>Rgister</h2>
                        </div>
                        {{Form::open(['route'=>'customer-registration'])}}
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                {{Form::text('first_name','',['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'First Name','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::text('last_name','',['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'Last Name','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::email('email','',['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::password('password',['class'=>'form-control','minlength'=>'8','maxlength'=>'40','placeholder'=>'Password','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                <select class="w-100" name="country">
                                    <option value="usa">--Country--</option>
                                    <option value="uk">United Kingdom</option>
                                    <option value="ger">Germany</option>
                                    <option value="fra">France</option>
                                    <option value="ind">India</option>
                                    <option value="aus">Australia</option>
                                    <option value="bra">Brazil</option>
                                    <option value="cana">Canada</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('street_address','',['class'=>'form-control','placeholder'=>'Address','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('city','',['class'=>'form-control','placeholder'=>'Town','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::text('zipCode','',['class'=>'form-control','placeholder'=>'Zip Code','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                <input type="number" class="form-control" name="phone_number" min="0" placeholder="Phone No" required value="">
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::textarea('comment','',['class'=>'form-control w-100','cols'=>'30','rows'=>'10','placeholder'=>'Leave a comment about your order','required'])}}
                            </div>

                            <div class="col-12 mb-3">
                                <input type="submit" name="btn" class="btn btn-success w-25" value="Rgister">
                            </div>
                        </div>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->
@endsection