@extends('front-end.master')
@section('title','Checkout')
@section('body')
    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-12 well">
                    <h6 style="background: #ececec;padding: 10px 0;border: 1px solid #dedbdb;border-radius: 5px;" class="text-success">&nbsp; Dear {{Session::get('customerName')}}, please select your payment method.</h6>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-4">
                    <div style="margin-top: 50px;" class="cart-summary">
                    <h5>Payment</h5>
                    {{Form::open(['route'=>'placed-order'])}}
                        <ul class="summary-table">
                        <li><span>subtotal:</span> <span>${{Session::get('orderTotal')}}</span></li>
                        <li><span>delivery:</span> <span>Free</span></li>
                        <li><span>total:</span> <span>${{Session::get('orderTotal')}}</span></li>
                        </ul>

                        <div class="payment-method">
                        <!-- Cash on delivery -->
                        <div class="custom-control custom-checkbox pl-0 mb-2 mr-sm-2">
                            <input type="radio" name="payment_type" value="Cash"> Cash on Delivery
                        </div>
                        <!-- Bkash -->
                        <div class="custom-control custom-checkbox pl-0 mb-2 mr-sm-2">
                            <input type="radio" name="payment_type" value="Bkash" checked> Bkash
                        </div>
                        <!-- Paypal -->
                        <div class="custom-control custom-checkbox pl-0 mr-sm-2">
                        <input type="radio" name="payment_type" value="Paypal"> Paypal <img class="ml-15" src="{{asset('')}}assets/img/core-img/paypal.png" alt=""></label>
                        </div>
                        </div>

                        <div class="cart-btn mt-70">
                            <input type="submit" name="btn" class="btn amado-btn w-100" value="Confirm Order">
                        </div>
                    {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->
@endsection