@extends('front-end.master')
@section('title','Checkout')
@section('body')
    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-12 well">
                    <h6 style="background: #ececec;padding: 10px 0;border: 1px solid #dedbdb;border-radius: 5px;" class="text-center text-success">
                        Dear {{Session::get('customerName')}}, you have to give us shipping info to complete your order :)
                    </h6>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="checkout_details_area mt-30 clearfix">
                        <div class="cart-title">
                            <h6>Shipping info goes here.</h6>
                            <hr/>
                        </div>
                        {{Form::open(['route'=>'new-shipping'])}}
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                {{Form::text('full_name',"{$customer->first_name}",['class'=>'form-control','minlength'=>'4','maxlength'=>'25','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::email('email_address',"{$customer->email}",['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('country',"{$customer->country}",['class'=>'form-control','placeholder'=>'Country','minlength'=>'4','maxlength'=>'25','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('street_address',"{$customer->address}",['class'=>'form-control','placeholder'=>'Address','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('city',"{$customer->city}",['class'=>'form-control','placeholder'=>'Town','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::text('zipCode',"{$customer->zipCode}",['class'=>'form-control','placeholder'=>'Zip Code','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::number('phone_number','',['class'=>'form-control','minlength'=>'9','maxlength'=>'20','placeholder'=>'Phone Number','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                <input type="submit" name="btn" class="btn btn-success w-25" value="Save shipping info">
                            </div>
                        </div>
                        {{Form::close()}}
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->
@endsection