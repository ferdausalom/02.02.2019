@extends('front-end.master')
@section('title','Login')
@section('body')
    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="login-form">
                        <div class="checkout_details_area mt-50 clearfix">
                            <div style="padding-top: 48px;" class="cart-title">
                                <h5>Login here:</h5>
                                <hr/>
                            </div>
                            {{Form::open(['route'=>'account-login'])}}
                            <div class="row">
                                <div class="col-12 mb-3">
                                    {{Form::email('email','',['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])}}
                                </div>
                                <div class="col-12 mb-3">
                                    {{Form::password('password',['class'=>'form-control','minlength'=>'8','maxlength'=>'40','placeholder'=>'Password','required'])}}
                                </div>
                                <div class="col-12 mb-3">
                                    <input type="submit" name="btn" class="btn btn-success w-25" value="Login">
                                </div>
                                {{--<div class="col-12">--}}
                                {{--<div class="custom-control custom-checkbox d-block">--}}
                                {{--<input type="checkbox" class="custom-control-input" id="customCheck3">--}}
                                {{--<label class="custom-control-label" for="customCheck3">Ship to a different address</label>--}}
                                {{--</div>--}}
                                {{--</div>--}}
                            </div>
                            {{Form::close()}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->
@endsection