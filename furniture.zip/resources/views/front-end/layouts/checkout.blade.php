@extends('front-end.master')
@section('title','Checkout')
@section('body')
<div class="cart-table-area section-padding-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-12 well">
                <h6 style="background: #ececec;padding: 10px 0;border: 1px solid #dedbdb;border-radius: 5px;" class="text-center text-danger">You have to login to complete  your order. If you are not registered yet then register first.</h6>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-lg-8">
                <div class="checkout_details_area mt-30 clearfix">

                    <div class="cart-title">
                        <h2>Checkout</h2>
                        <h6>Rgister here</h6>
                    </div>
                    {{Form::open(['route'=>'customer-sign-up'])}}
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                {{Form::text('first_name','',['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'First Name','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::text('last_name','',['class'=>'form-control','minlength'=>'4','maxlength'=>'20','placeholder'=>'Last Name','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::email('email','',['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::password('password',['class'=>'form-control','minlength'=>'8','maxlength'=>'40','placeholder'=>'Password','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                <select class="w-100" name="country">
                                    <option value="usa">--Country--</option>
                                    <option value="uk">United Kingdom</option>
                                    <option value="ger">Germany</option>
                                    <option value="fra">France</option>
                                    <option value="ind">India</option>
                                    <option value="aus">Australia</option>
                                    <option value="bra">Brazil</option>
                                    <option value="cana">Canada</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('street_address','',['class'=>'form-control','placeholder'=>'Address','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::text('city','',['class'=>'form-control','placeholder'=>'Town','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                {{Form::text('zipCode','',['class'=>'form-control','placeholder'=>'Zip Code','required'])}}
                            </div>
                            <div class="col-md-6 mb-3">
                                <input type="number" class="form-control" name="phone_number" min="0" placeholder="Phone No" required value="">
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::textarea('comment','',['class'=>'form-control w-100','cols'=>'30','rows'=>'10','placeholder'=>'Leave a comment about your order','required'])}}
                            </div>

                            {{--<div class="col-12">--}}
                                {{--<div class="custom-control custom-checkbox d-block mb-2">--}}
                                    {{--<input type="checkbox" class="custom-control-input" id="customCheck2">--}}
                                    {{--<label class="custom-control-label" for="customCheck2">Create an accout</label>--}}
                                {{--</div>--}}
                                {{--<div class="custom-control custom-checkbox d-block">--}}
                                    {{--<input type="checkbox" class="custom-control-input" id="customCheck3">--}}
                                    {{--<label class="custom-control-label" for="customCheck3">Ship to a different address</label>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                            <div class="col-12 mb-3">
                                <input type="submit" name="btn" class="btn btn-success w-25" value="Rgister">
                            </div>
                        </div>
                    {{Form::close()}}
                </div>
            </div>
            <div class="col-12 col-lg-4">
                <div class="login-form">
                    <div class="checkout_details_area mt-50 clearfix">
                        <div style="padding-top: 48px;" class="cart-title">
                            <h6>Already signed up? Login here</h6>
                        </div>

                        {{Form::open(['route'=>'customer-sign-up'])}}
                        <div class="row">
                            <div class="col-12 mb-3">
                                {{Form::email('email','',['class'=>'form-control','minlength'=>'9','maxlength'=>'40','placeholder'=>'Email','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                {{Form::password('password',['class'=>'form-control','minlength'=>'8','maxlength'=>'40','placeholder'=>'Password','required'])}}
                            </div>
                            <div class="col-12 mb-3">
                                <input type="submit" name="btn" class="btn btn-success w-25" value="Login">
                            </div>
                            {{--<div class="col-12">--}}
                                {{--<div class="custom-control custom-checkbox d-block">--}}
                                    {{--<input type="checkbox" class="custom-control-input" id="customCheck3">--}}
                                    {{--<label class="custom-control-label" for="customCheck3">Ship to a different address</label>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                        </div>
                        {{Form::close()}}
                    </div>
                </div>
                {{--<div style="margin-top: 50px;" class="cart-summary">--}}
                    {{--<h5>Cart Total</h5>--}}
                    {{--<ul class="summary-table">--}}
                        {{--<li><span>subtotal:</span> <span>$140.00</span></li>--}}
                        {{--<li><span>delivery:</span> <span>Free</span></li>--}}
                        {{--<li><span>total:</span> <span>$140.00</span></li>--}}
                    {{--</ul>--}}

                    {{--<div class="payment-method">--}}
                        {{--<!-- Cash on delivery -->--}}
                        {{--<div class="custom-control custom-checkbox mr-sm-2">--}}
                            {{--<input type="checkbox" class="custom-control-input" id="cod" checked>--}}
                            {{--<label class="custom-control-label" for="cod">Cash on Delivery</label>--}}
                        {{--</div>--}}
                        {{--<!-- Paypal -->--}}
                        {{--<div class="custom-control custom-checkbox mr-sm-2">--}}
                            {{--<input type="checkbox" class="custom-control-input" id="paypal">--}}
                            {{--<label class="custom-control-label" for="paypal">Paypal <img class="ml-15" src="{{asset('')}}assets/img/core-img/paypal.png" alt=""></label>--}}
                        {{--</div>--}}
                    {{--</div>--}}

                    {{--<div class="cart-btn mt-70">--}}
                        {{--<a href="#" class="btn amado-btn w-100">Checkout</a>--}}
                    {{--</div>--}}
                {{--</div>--}}
            </div>
        </div>
    </div>
</div>
</div>
<!-- ##### Main Content Wrapper End ##### -->
@endsection