@extends('front-end.master')
@section('title','Cart')
@section('body')

    <div class="cart-table-area section-padding-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-lg-8">
                    <div class="cart-title mt-50">
                        <h2>Shopping Cart</h2>
                    </div>

                    <div class="cart-table clearfix">
                        <table class="table text-center table-responsive">
                            <thead>
                            <tr>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Image</th>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Name</th>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Price</th>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Quantity</th>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Total Price</th>
                                <th style="width: 16%;max-width: 16%;    font-size: 15px;">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @php($sum=0)
                            @php($sum_qty=0)
                            @foreach($cartProducts as $cartProduct)
                            <tr>
                                <td style="width: 16%;max-width: 16%;" class="cart_product_img">
                                    <img width="100" height="70" src="{{asset($cartProduct->options->image)}}" alt="{{$cartProduct->name}}">
                                </td>
                                <td style="width: 16%;max-width: 16%;" class="cart_product_desc">
                                    <h5>{{$cartProduct->name}}</h5>
                                </td>
                                <td style="width: 16%;max-width: 16%;" class="price">
                                    <span>${{$cartProduct->price}}</span>
                                </td>
                                <td style="width: 16%;max-width: 16%;" class="qty">
                                    <div class="qty-btn d-flex">
                                        <div class="quantity">
                                            {{Form::open(['route'=>'update-cart-qty'])}}
                                            <input type="number" class="qty-text" min="1" name="qty" value="{{$addedQty = $cartProduct->qty}}">
                                            <input type="hidden" class="qty-text" min="1" name="rowId" value="{{$cartProduct->rowId}}">
                                            <input type="submit" class="btn btn-success" style="font-size: 12px;" value="Update">
                                            {{Form::close()}}
                                        </div>
                                    </div>
                                </td>
                                <td style="width: 16%;max-width: 16%;" class="price">
                                    <span>${{$total = $cartProduct->price*$cartProduct->qty}}</span>
                                </td>
                                <td style="width: 16%;max-width: 16%;">
                                    <a href="{{route('delete-cart-item',['rowId'=>$cartProduct->rowId])}}" class="btn btn-danger btn-xs" title="Remove">
                                        Remove
                                    </a>
                                </td>
                            </tr>
                                <?php $sum = $sum+$total;$sum_qty = $sum_qty+$addedQty?>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-12 col-lg-4">
                    <div class="cart-summary">
                        <h5>Cart Total</h5>
                        <ul class="summary-table">
                            <li><span>subtotal:</span> <span>${{$sum}}</span></li>
                            <li><span>Vat:</span> <span>{{$vat=0}}</span></li>
                            <li><span>delivery:</span> <span>Free</span></li>
                            <li><span>Quantity:</span> <span>{{$sum_qty}}</span></li>
                            <li><span>total:</span> <span>${{$orderttotal = $sum+$vat}}</span></li>
                            <?php Session::put('orderTotal',$orderttotal);?>
                            <?php Session::put('totalQty',$sum_qty);?>
                        </ul>
                        <div class="cart-btn mt-100">
                            <a href="{{route('my-shop')}}" class="btn btn-success w-45">Continue Shopping</a> &nbsp;&nbsp;
                            @if(Session::get('customerId') && Session::get('shippingId'))
                                <a href="{{route('checkout-shipping' )}}" class="btn btn-success w-45 pull-right">Checkout</a>
                            @elseif(Session::get('customerId'))
                                <a href="{{route('order-payment' )}}" class="btn btn-success w-45 pull-right">Checkout</a>
                            @else
                                <a href="{{route('checkout' )}}" class="btn btn-success w-45 pull-right">Checkout</a>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- ##### Main Content Wrapper End ##### -->

@endsection