@extends('front-end.master')
@section('title','Home')
@section('body')
    <div class="products-catagories-area clearfix">
        <div class="amado-pro-catagory clearfix">
            <!-- Single Catagory -->
            @foreach($products as $product)
            <div class="single-products-catagory clearfix">
                <a href="{{route('details-product',['id'=>$product->id, 'name'=>$product->product_name])}}">
                    <img src="{{asset('')}}{{$product->product_image}}" alt="{{$product->product_name}}" />
                    <!-- Hover Content -->
                    <div class="hover-content">
                        <div class="line"></div>
                        <p>Price ${{$product->product_price}}</p>
                        <h4>{{$product->product_name}}</h4>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>
@endsection