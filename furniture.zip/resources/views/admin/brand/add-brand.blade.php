@extends('admin.master')
@section('title','Add Brand')
@section('body')
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-6" style="margin-top: 85px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">Add Brand</h4>
                        @if (session('message'))
                            <h4 class="text-center text-success"> {{ session('message') }}</h4>
                        @endif
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                {{Form::open(['route'=>'new-brand','method'=>'POST','role'=>'form'])}}
                                    <div class="form-group">
                                        <label>Name</label>
                                        {{Form::text('brand_name','',['class'=>'form-control','placeholder'=>'Brand Name','required'])}}
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        {{Form::textarea('brand_description','',['class'=>'form-control','rows'=>'3','placeholder'=>'Brand Description','required'])}}
                                    </div>
                                    <div class="form-group" >
                                        <label class="col-md-12">Publication Status</label>
                                        <label class="col-md-12"><input type="radio" checked name="publication_status" value="1" /> Published</label>
                                        <label class="col-md-12" style="margin-bottom: 20px;"><input type="radio" name="publication_status" value="0" /> Unublished</label>
                                    </div>
                                    {{--<div class="form-group">--}}
                                    {{--<label>Image</label>--}}
                                    {{--<input type="file">--}}
                                    {{--</div>--}}
                                    <input type="submit" name="btn" class="btn btn-success" value="Save Category Info"> &nbsp;&nbsp;
                                    <button type="reset" class="btn btn-warning">Reset</button>
                                {{Form::close()}}
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
@endsection