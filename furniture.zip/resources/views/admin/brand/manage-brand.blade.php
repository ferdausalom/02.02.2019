@extends('admin.master')
@section('title','Manage Brand')
@section('body')
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-8" style="margin-top: 85px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">Manage Brand</h4>
                        @if (session('message'))
                            <h4 class="text-center text-success"> {{ session('message') }}</h4>
                        @endif
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th class="text-center">SL NO:</th>
                                    <th class="text-center">Brand Name</th>
                                    <th class="text-center">Brand Description</th>
                                    <th class="text-center">Publication Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @php($i=1)
                                @foreach($brands as $brand)
                                    <tr class="text-center">
                                        <td>{{$i++}}</td>
                                        <td>{{$brand->brand_name}}</td>
                                        <td>{{$brand->brand_description}}</td>
                                        <td>{{$brand->publication_status == 1? 'Published':'Unpublished'}}</td>
                                        <td>
                                            @if($brand->publication_status == 1)
                                                <a href="{{route('unpublished-brand',['id'=>$brand->id])}}" class="btn btn-info">
                                                    <span class="glyphicon glyphicon-arrow-up"></span>
                                                </a>
                                            @else
                                                <a href="{{route('published-brand',['id'=>$brand->id])}}" class="btn btn-warning">
                                                    <span class="glyphicon glyphicon-arrow-down"></span>
                                                </a>
                                            @endif
                                            <a href="{{route('edit-brand-info',['brand_name'=>$brand->id])}}" class="btn btn-success">
                                                <span class="glyphicon glyphicon-edit"></span>
                                            </a>
                                            <a onclick="return confirm('are you sure to delete it?')" href="{{route('delete-brand-info',['id'=>$brand->id])}}" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.row -->
    </div>
@endsection