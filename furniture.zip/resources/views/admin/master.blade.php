<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <!-- Core CSS - Include with every page -->
    <link href="{{asset('')}}admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="{{asset('')}}admin/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="{{asset('')}}admin/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="{{asset('')}}admin/css/sb-admin.css" rel="stylesheet">
    <script src="{{asset('')}}admin/ckeditor/ckeditor.js"></script>
    <script src="{{asset('')}}admin/ckeditor/samples/js/sample.js"></script>
    <link rel="stylesheet" href="{{asset('')}}admin/ckeditor/samples/css/samples.css">
    <link rel="stylesheet" href="{{asset('')}}admin/ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
</head>
<body>
<div id="wrapper">
    @include('admin.inc.menu')
    @yield('body')
    <!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
@include('admin.inc.footer')
