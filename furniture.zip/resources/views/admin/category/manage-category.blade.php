@extends('admin.master')
@section('title','Manage Category')
@section('body')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-8" style="margin-top: 20px;">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center">Manage Category</h4>
                    @if (session('message'))
                        <h4 class="text-center text-success"> {{ session('message') }}</h4>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th class="text-center">SL NO:</th>
                                <th class="text-center">Category Name</th>
                                <th class="text-center">Category Description</th>
                                <th class="text-center">Publication Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @php($i=1)
                            @foreach($categories as $category)
                            <tr class="text-center">
                                <td>{{$i++}}</td>
                                <td>{{$category->category_name}}</td>
                                <td>{{$category->category_description}}</td>
                                <td>{{$category->publication_status == 1? 'Published':'Unpublished'}}</td>
                                <td>
                                    @if($category->publication_status == 1)
                                    <a href="{{route('unpublished-category',['id'=>$category->id])}}" class="btn btn-info">
                                        <span class="glyphicon glyphicon-arrow-up"></span>
                                    </a>
                                    @else
                                    <a href="{{route('published-category',['id'=>$category->id])}}" class="btn btn-warning">
                                        <span class="glyphicon glyphicon-arrow-down"></span>
                                    </a>
                                    @endif
                                    <a href="{{route('edit-category-info',['id'=>$category->id])}}" class="btn btn-success">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a onclick="return confirm('are you sure to delete it?')" href="{{route('delete-category-info',['id'=>$category->id])}}" class="btn btn-danger">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <!-- /.row -->
</div>
@endsection