@extends('admin.master')
@section('title','Add Product')
@section('body')
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-6" style="margin-top: 85px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">Add Product</h4>
                        @if (session('message'))
                            <h4 class="text-center text-success"> {{ session('message') }}</h4>
                        @endif
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                {{Form::open(['route'=>'new-product','id'=>'product-form','method'=>'POST','role'=>'form','enctype'=>'multipart/form-data'])}}
                                <div class="form-group">
                                    <label>Product Name</label>
                                    {{Form::text('product_name','',['class'=>'form-control','placeholder'=>'Product Name','required'])}}
                                </div>
                                <div class="form-group">
                                    <label>Category Name</label>
                                    <select class="form-control" name="category_id">
                                        <option>-- Select Category --</option>
                                        @foreach($categories as $category)
                                            <option value="{{$category->id}}">{{$category->category_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Brand Name</label>
                                    <select class="form-control" name="brand_id">
                                        <option>-- Select Brand --</option>
                                        @foreach($brands as $brand)
                                            <option value="{{$brand->id}}">{{$brand->brand_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Product Price</label>
                                    {{Form::number('product_price','',['class'=>'form-control','placeholder'=>'Product Price','required'])}}
                                </div>
                                <div class="form-group">
                                    <label>Product Quantity</label>
                                    {{Form::number('product_quantity','',['class'=>'form-control','placeholder'=>'Product Quantity','required'])}}
                                </div>
                                <div class="form-group">
                                    <label>Short Description</label>
                                    {{Form::textarea('short_description','',['class'=>'form-control','rows'=>'3','placeholder'=>'Short Description','required'])}}
                                </div>
                                <div class="form-group">
                                    <label>Long Description</label>
                                    {{Form::textarea('long_description','',['id'=>'editor','class'=>'form-control','rows'=>'3'])}}
                                </div>
                                <div class="form-group">
                                    <label>Product Image</label>
                                    {{Form::file('product_image',['accept'=>'image/*','required'])}}
                                </div>
                                <div class="form-group" >
                                    <label class="col-md-12">Publication Status</label>
                                    <label class="col-md-12"><input type="radio" checked name="publication_status" value="1" /> Published</label>
                                    <label class="col-md-12" style="margin-bottom: 20px;"><input type="radio" name="publication_status" value="0" /> Unublished</label>
                                </div>
                                <input type="submit" name="btn" class="btn btn-success" value="Save Product Info"> &nbsp;&nbsp;
                                <button type="reset" class="btn btn-warning">Reset</button>
                                {{Form::close()}}
                            </div>
                            <!-- /.col-lg-6 (nested) -->
                            <!-- /.col-lg-6 (nested) -->
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
@endsection