@extends('admin.master')
@section('title','All Product')
@section('body')
    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12" style="margin-top: 85px;">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h4 class="text-center">All Product</h4>
                        @if (session('message'))
                            <h4 class="text-center text-success"> {{ session('message') }}</h4>
                        @endif
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-responsive table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                <tr>
                                    <th>Sl No.</th>
                                    <th>Product Name</th>
                                    <th>Category Name</th>
                                    <th>Brand Name</th>
                                    <th>Product Price</th>
                                    <th>Product Quantity</th>
                                    <th>Product Short Description</th>
                                    <th>Product Image</th>
                                    <th>Product Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @php($i=1)
                                @foreach($products as $product)
                                    <tr class="text-center">
                                        <td>{{$i++}}</td>
                                        <td>{{$product->product_name}}</td>
                                        <td>{{$product->category_name}}</td>
                                        <td>{{$product->brand_name}}</td>
                                        <td>${{$product->product_price}}</td>
                                        <td>{{$product->product_quantity}}</td>
                                        <td width="30%">{{$product->short_description}}</td>
                                        <td><img width="50" height="50" src="{{asset($product->product_image)}}"/></td>
                                        <td>{{$product->publication_status==1?'published':'Unpublished'}}</td>
                                        <td width="5%">
                                            @if($product->publication_status==1)
                                                <a style="margin-bottom: 8px;" href="{{route('unpublished-product',['id'=>$product->id])}}" class="btn btn-info">
                                                    <span class="glyphicon glyphicon-arrow-up"></span>
                                                </a>
                                            @else
                                                <a style="margin-bottom: 8px;" href="{{route('publish-product',['id'=>$product->id])}}" class="btn btn-warning">
                                                    <span class="glyphicon glyphicon-arrow-down"></span>
                                                </a>
                                            @endif
                                            <a style="margin-bottom: 8px;" href="{{route('edit-product',['id'=>$product->id])}}" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-edit"></span>
                                            </a>
                                            <a onclick="return confirm('are you sure to delete?')" href="{{route('product-delete',['id'=>$product->id])}}" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-trash"></span>
                                            </a>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <!-- /.row -->
    </div>
@endsection