<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ShopController extends Controller
{
   public function shopPage(){
       return view('front-end.layouts.shop');
   }
}
