<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductDetailsController extends Controller
{
    public function productDetails(){
        return view('front-end.layouts.product-details');
    }
}
