<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <!-- Title  -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon  -->
    <link rel="icon" href="<?php echo e(asset('')); ?>assets/img/core-img/favicon2.ico">
    <!-- Core Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/css/core-style.css">
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/style.css">
</head>
<body>
<!-- Search Wrapper Area Start -->
<?php echo $__env->make('front-end.inc.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Header Area End -->
    <!-- Product Catagories Area Start -->
<?php echo $__env->yieldContent('body'); ?>
    <!-- Product Catagories Area End -->
<!-- ##### Main Content Wrapper End ##### -->
<!-- ##### Newsletter Area Start ##### -->
<?php echo $__env->make('front-end.inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>