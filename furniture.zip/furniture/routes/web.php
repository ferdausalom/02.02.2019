<?php

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/',[
   'uses' =>'HomePageController@homePage',
   'as'   =>'/'
]);

Route::get('/shop',[
   'uses' =>'ShopController@shopPage',
   'as'   =>'my-shop'
]);

Route::get('/product',[
   'uses' =>'ProductDetailsController@productDetails',
   'as'   =>'details-product'
]);

Route::get('/checkout',[
   'uses' =>'CheckoutController@checkout',
   'as'   =>'check-out'
]);

Route::get('/cart',[
   'uses' =>'CartController@cart',
   'as'   =>'shop-cart'
]);

