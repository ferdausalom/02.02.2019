<?php

namespace App\Http\Controllers;

use App\Brand;
use App\Category;
use App\Product;
use Illuminate\Http\Request;
use Image;
use DB;

class ProductController extends Controller
{
    public function index(){
        //see also AppServiceProvider
        return view('admin.product.add-product');
    }

    protected function productImageInfo($request){
        $productImage = $request->file('product_image');
        $fileType = $productImage->getClientOriginalExtension();
        $productName = $request->product_name;
        $trimProductName = preg_replace("/[^a-zA-Z]+/", "", $productName);
        $imgName = $trimProductName.'.'.$fileType;
        $directory = 'product-image/';
        $imageUrl = $directory.$imgName;
        Image::make($productImage)->resize(500, null, function ($constraint) {
            $constraint->aspectRatio();
        })->save($imageUrl);
        return $imageUrl;
    }

    protected function productInfoSave($request, $imageUrl){
        $product = new Product();
        $productName = $request->product_name;
        $trimProductName = preg_replace('/[^a-zA-Z\s]/', '', $productName);
        $product->product_name = $trimProductName;
        $product->category_id = $request->category_id;
        $product->brand_id = $request->brand_id;
        $product->product_price = $request->product_price;
        $product->product_quantity = $request->product_quantity;
        $product->short_description = $request->short_description;
        $product->long_description = $request->long_description;
        $product->product_image = $imageUrl;
        $product->publication_status = $request->publication_status;
        $product->save();
    }

    public function saveProduct(Request $request){
        $imageUrl = $this->productImageInfo($request);
        $this->productInfoSave($request, $imageUrl);

        return redirect('product/add')->with('message','Product info inserted successfully');
    }

    public function manageProduct(){
        $products = DB::table('products')
                    ->join('categories','products.category_id','=','categories.id')
                    ->join('brands','products.brand_id','=','brands.id')
                    ->select('products.*','categories.category_name','brands.brand_name')
                    ->get();

        return view('admin.product.manage-product',['products'=>$products]);
    }

    public function unpublishProduct($id){
        $product = Product::find($id);
        $product->publication_status = 0;
        $product->save();

        return redirect('product/show')->with('message','Product unpublished successfully');
    }

    public function publishProduct($id){
        $product = Product::find($id);
        $product->publication_status = 1;
        $product->save();

        return redirect('product/show')->with('message','Product published successfully');
    }

    public function editProduct($id){
        $product = Product::find($id);
        //see also AppServiceProvider
        return view('admin.product.edit-product',['product'=>$product]);
    }

    protected function updateProductImage($request, $productImage){
        $productName = $request->product_name;
        $fileType = $productImage->getClientOriginalExtension();
        $trimProductName = preg_replace("/[^a-zA-Z]+/", "", $productName);
        $imgName = $trimProductName.'.'.$fileType;
        $directory = 'product-image/';
        $imageUrl = $directory.$imgName;
        Image::make($productImage)->resize(500, null, function ($constraint) {
            $constraint->aspectRatio();
        })->save($imageUrl);

        return $imageUrl;
    }

    protected function saveProductBasicInfo($product, $request, $imageUrl=null){
        $product->product_name = $request->product_name;
        $product->category_id = $request->category_id;
        $product->brand_id = $request->brand_id;
        $product->product_price = $request->product_price;
        $product->product_quantity = $request->product_quantity;
        $product->short_description = $request->short_description;
        $product->long_description = $request->long_description;
        if ($imageUrl){$product->product_image = $imageUrl;}
        $product->publication_status = $request->publication_status;
    }

    public function updateProduct(Request $request){
        $product = Product::find($request->product_id);
        $productImage = $request->file('product_image');

        if ($productImage){
            unlink($product->product_image);
            $imageUrl = $this->updateProductImage($request, $productImage);
            $this->saveProductBasicInfo($product, $request, $imageUrl);
            $product->save();

        }else{
            $this->saveProductBasicInfo($product,$request);
            $product->save();
        }
        //see also AppServiceProvider
        return redirect('/product/show')->with('message','Product info updated successfully');
    }

    public function deleteProduct($id){
        $product = Product::find($id);
        $product->delete();

        return redirect('/product/show')->with('message',"Product '{$product->product_name}' deleted successfully");
    }

}
