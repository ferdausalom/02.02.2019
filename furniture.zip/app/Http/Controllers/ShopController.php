<?php

namespace App\Http\Controllers;

use App\Brand;
use App\Category;
use App\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
   public function shopPage(){
       $categories = Category::where('publication_status',1)->get();
       $brands = Brand::where('publication_status',1)->get();
       $products = Product::where('publication_status',1)->get();

       //return view('front-end.layouts.shop',compact('categories','brands','products'));
       return view('front-end.layouts.shop',[
           'categories'=>$categories,
           'brands'=>$brands,
           'products'=>$products,
       ]);
   }
}
