<?php

namespace App\Http\Controllers;

use App\Customer;
use App\Order;
use App\OrderDetail;
use App\Payment;
use App\Shipping;
use Illuminate\Http\Request;
use Cart;
use Session;
use Mail;


class CheckoutController extends Controller
{
    public function checkout(){
        return view('front-end.layouts.checkout');
    }

    public function index(){
        return view('front-end.layouts.checkout');
    }

    public function userRegistration(){
        return view('front-end.layouts.register');
    }

    public function customerRegistration(Request $request){
        $customer = new Customer();
        $customer->first_name = $request->first_name;
        $customer->last_name = $request->last_name;
        $customer->email = $request->email;
        $customer->password = bcrypt($request->password);
        $customer->country = $request->country;
        $customer->street_address = $request->street_address;
        $customer->city = $request->city;
        $customer->zipCode = $request->zipCode;
        $customer->comment = $request->comment;
        $customer->save();

        $customerId = $customer->id;
        Session::put('customerId',$customerId);
        Session::put('customerName',$customer->first_name.' '.$customer->last_name);

        $data = $customer->toArray();

        Mail::send('front-end.mails.confirmation-mail',$data, function ($message) use ($data){
            $message->to($data['email']);
            $message->subject('Confirmation Mail');
        });

        return redirect('/profile');
    }

    public function customerProfile(){
        return view('front-end.layouts.profile');
    }

    public function customerLogin(){
        return view('front-end.layouts.login');
    }

    public function accountLogin(){
        return view('front-end.layouts.login');
    }

    public function customerSignUp(Request $request){
        $customer = new Customer();
        $customer->first_name = $request->first_name;
        $customer->last_name = $request->last_name;
        $customer->email = $request->email;
        $customer->password = bcrypt($request->password);
        $customer->country = $request->country;
        $customer->street_address = $request->street_address;
        $customer->city = $request->city;
        $customer->zipCode = $request->zipCode;
        $customer->comment = $request->comment;
        $customer->save();

        $customerId = $customer->id;
        Session::put('customerId',$customerId);
        Session::put('customerName',$customer->first_name.' '.$customer->last_name);

        $data = $customer->toArray();

        Mail::send('front-end.mails.confirmation-mail',$data, function ($message) use ($data){
            $message->to($data['email']);
            $message->subject('Confirmation Mail');
        });

        return redirect('/checkout/shipping');
    }

    public function shippingForm(){
        $customer = Customer::find(Session::get('customerId'));
        return view('front-end.layouts.shipping',['customer'=>$customer]);
    }

    public function saveShippingInfo(Request $request){
        $shipping = new Shipping();

        $shipping->full_name = $request->full_name;
        $shipping->email_address = $request->email_address;
        $shipping->country = $request->country;
        $shipping->street_address = $request->street_address;
        $shipping->city = $request->city;
        $shipping->zipCode = $request->zipCode;
        $shipping->phone_number = $request->phone_number;
        $shipping->save();

        $ship = $shipping->id;
        Session::put('shipId',$ship);

        return redirect('/checkout/payment');

    }

    public function paymentForm(){
        return view('front-end.layouts.payment');
    }

    public function placedOrder(Request $request){
        $paymentType = $request->payment_type;
        if ($paymentType == 'Cash'){
            $order = new Order();
            $order->customer_id = Session::get('customerId');
            $order->shipping_id = Session::get('shipId');
            $order->order_total = Session::get('orderTotal');
            $order->save();

            $payment = new Payment();
            $payment->order_id = $order->id;
            $payment->payment_type = $paymentType;
            $payment->save();

            $cartProducts = Cart::content();
            foreach ($cartProducts as $cartProduct){
                $orderDetail = new OrderDetail();
                $orderDetail->order_id = $order->id;
                $orderDetail->product_id = $cartProduct->id;
                $orderDetail->product_name = $cartProduct->name;
                $orderDetail->product_price = $cartProduct->price;
                $orderDetail->product_quantity = $cartProduct->qty;
                $orderDetail->save();

                Cart::destroy();

                return redirect('/complete/order');
            }
        }
        else if ($paymentType == 'Bkash'){

        }else if ($paymentType == 'Paypal'){

        }
    }

    public function completedOrder(){
        return 'success';
    }
}
