<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
//Active it, if you use QUERY BUILDER METHOD
//use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    //Link for manage add category page
    public function addCategory(){
        return view('admin.category.add-category');
    }

    public function saveCategory(Request $request){

        // INSERT METHOD 1/Eloquent ORM
        $category = new Category();
        $category->category_name = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publication_status = $request->publication_status;
        $category->save();

        //INSERT METHOD 2/QUERY BUILDER METHOD
//        DB::table('categories')->insert([
//            'category_name' => $request->category_name,
//        ]);

        return redirect('add-category')->with('message','Category info inserted successfully');
    }

    //Link for manage category page
    public function manageCategory(){
        $categories = Category::all();
        return view('admin.category.manage-category',['categories'=>$categories]);
    }

    public function unpublishedCategory($id){
        $category = Category::find($id);
        $category->publication_status =0;
        $category->save();

        return redirect('manage-category')->with('message','Category unpublished successfully');
    }

    public function publishedCategory($id){
        $category = Category::find($id);
        $category->publication_status =1;
        $category->save();

        return redirect('manage-category')->with('message','Category published successfully');
    }

    public function editCategory($id){
        $category = Category::find($id);

        return view('admin.category.edit-category',['category'=>$category]);
    }

    public function updateCategory(Request $request){
        $category = Category::find($request->category_id);
        $category->category_name = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publication_status = $request->publication_status;
        $category->save();

        return redirect('manage-category')->with('message','Category info updated successfully');
    }

    public function deleteCategory($id){
        $category = Category::find($id);
        $category->delete();

        return redirect('manage-category')->with('message','Category info deleted successfully');
    }


}
