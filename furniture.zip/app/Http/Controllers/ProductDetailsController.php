<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class ProductDetailsController extends Controller
{
    public function productDetails($id){
        $productDetails = Product::where('id',$id)
                        ->where('publication_status',1)
                        ->get();
        return view('front-end.layouts.product-details',['productDetails'=>$productDetails]);
    }
}
