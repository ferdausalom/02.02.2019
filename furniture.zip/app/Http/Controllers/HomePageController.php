<?php

namespace App\Http\Controllers;
use App\Product;
use Illuminate\Http\Request;
class HomePageController extends Controller
{
   public function homePage(){
       $products = Product::where('publication_status',1)
           ->orderBy('id','DESC')
           ->take(9)
           ->get();
       return view('front-end.home',['products'=>$products]);
   }

    public function categoryProduct($id){
        //see also AppServiceProvider
        $categoryProducts = Product::where('category_id',$id)
                            ->where('publication_status',1)
                            ->get();

        return view('front-end.layouts.category-product',['categoryProducts'=>$categoryProducts]);

    }
}
