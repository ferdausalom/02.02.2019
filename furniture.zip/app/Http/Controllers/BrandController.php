<?php

namespace App\Http\Controllers;

use App\Brand;
use Illuminate\Http\Request;

class BrandController extends Controller
{
    //Link for manage add brand page
    public function brandPage(){
        return view('admin.brand.add-brand');
    }

    public function saveBrand(Request $request){
        $brand = new Brand();
        $brand->brand_name = $request->brand_name;
        $brand->brand_description = $request->brand_description;
        $brand->publication_status = $request->publication_status;
        $brand->save();

        return redirect('brand-page')->with('message','Brand info inserted successfully');
    }

    public function manageBrand(){
        $brands = Brand::all();
        return view('admin.brand.manage-brand',['brands'=>$brands]);
    }

    public function unpublishBrand($id){
        $brand = Brand::find($id);
        $brand->publication_status=0;
        $brand->save();

        return redirect('manage-brand')->with('message','Brand unpublished successfully');
    }

    public function publishBrand($id){
        $brand = Brand::find($id);
        $brand->publication_status=1;
        $brand->save();

        return redirect('manage-brand')->with('message','Brand published successfully');
    }

    public function editBrand($id){
        $brand = Brand::find($id);

        return view('admin.brand.edit-brand',['brand'=>$brand]);
    }

    public function updateBrand(Request $request){
        $brand = Brand::find($request->brand_id);
        $brand->brand_name = $request->brand_name;
        $brand->brand_description = $request->brand_description;
        $brand->publication_status = $request->publication_status;
        $brand->save();

        return redirect('manage-brand')->with('message','Brand info updated successfully');
    }

    public function deleteBrand($id){
        $brand = Brand::find($id);
        $brand->delete();

        return redirect('manage-brand')->with('message',"Brand {$brand->brand_name} deleted successfully");
    }
}
