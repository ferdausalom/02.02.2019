<?php

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/',[
   'uses' =>'HomePageController@homePage',
   'as'   =>'/'
]);

Route::get('/shop',[
   'uses' =>'ShopController@shopPage',
   'as'   =>'my-shop'
]);

Route::get('/single/product/{id}',[
   'uses' =>'ProductDetailsController@productDetails',
   'as'   =>'details-product'
]);
//
//Route::get('/checkout',[
//   'uses' =>'CheckoutController@checkout',
//   'as'   =>'check-out'
//]);

Route::get('/cart',[
   'uses' =>'CartController@cart',
   'as'   =>'shop-cart'
]);

Route::get('/add-category',[
   'uses' =>'CategoryController@addCategory',
   'as'   =>'add-category-page'
]);

Route::post('/create-category',[
    'uses' =>'CategoryController@saveCategory',
    'as'   =>'new-category'
]);

Route::get('/manage-category',[
   'uses' =>'CategoryController@manageCategory',
   'as'   =>'manage-category-page'
]);

Route::get('/unpublished/category/{id}',[
   'uses' =>'CategoryController@unpublishedCategory',
   'as'   =>'unpublished-category'
]);

Route::get('/published/category/{id}',[
   'uses' =>'CategoryController@publishedCategory',
   'as'   =>'published-category'
]);

Route::get('/category/edit/{id}',[
   'uses' =>'CategoryController@editCategory',
   'as'   =>'edit-category-info'
]);

Route::post('/category/update',[
   'uses' =>'CategoryController@updateCategory',
   'as'   =>'update-category-info'
]);

Route::get('/category/delete/{id}',[
   'uses' =>'CategoryController@deleteCategory',
   'as'   =>'delete-category-info'
]);

Route::get('/brand-page',[
   'uses' =>'BrandController@brandPage',
   'as'   =>'add-brand-page'
]);

Route::post('/brand-page',[
   'uses' =>'BrandController@saveBrand',
   'as'   =>'new-brand'
]);

Route::get('/manage-brand',[
   'uses' =>'BrandController@manageBrand',
   'as'   =>'manage-brand-page'
]);

Route::get('/unpublish-brand/{id}',[
   'uses' =>'BrandController@unpublishBrand',
   'as'   =>'unpublished-brand'
]);

Route::get('/publish-brand/{id}',[
   'uses' =>'BrandController@publishBrand',
   'as'   =>'published-brand'
]);

Route::get('/edit-brand/{id}',[
   'uses' =>'BrandController@editBrand',
   'as'   =>'edit-brand-info'
]);

Route::post('/update-brand',[
   'uses' =>'BrandController@updateBrand',
   'as'   =>'update-brand-info'
]);

Route::get('/delete-brand/{id}',[
   'uses' =>'BrandController@deleteBrand',
   'as'   =>'delete-brand-info'
]);

Route::get('/product/add',[
   'uses' =>'ProductController@index',
   'as'   =>'add-product-page'
]);

Route::post('/product/save',[
   'uses' =>'ProductController@saveProduct',
   'as'   =>'new-product'
]);

Route::get('/product/show',[
   'uses' =>'ProductController@manageProduct',
   'as'   =>'manage-product'
]);

Route::get('/product/unpublish/{id}',[
   'uses' =>'ProductController@unpublishProduct',
   'as'   =>'unpublished-product'
]);

Route::get('/product/publish/{id}',[
   'uses' =>'ProductController@publishProduct',
   'as'   =>'publish-product'
]);

Route::get('/product/edit/{id}',[
   'uses' =>'ProductController@editProduct',
   'as'   =>'edit-product'
]);

Route::post('/product/update',[
   'uses' =>'ProductController@updateProduct',
   'as'   =>'update-product'
]);

Route::get('/delete/product/{id}',[
   'uses' =>'ProductController@deleteProduct',
   'as'   =>'product-delete'
]);

Route::get('/category/product/{id}',[
   'uses' =>'HomePageController@categoryProduct',
   'as'   =>'category-product'
]);

Route::post('/cart-add',[
   'uses' =>'CartController@addToCart',
   'as'   =>'add-to-cart'
]);

Route::get('/cart-show',[
   'uses' =>'CartController@showCart',
   'as'   =>'show-cart'
]);

Route::get('/cart/delete/{id}',[
   'uses' =>'CartController@deleteCart',
   'as'   =>'delete-cart-item'
]);

Route::post('/cart/update',[
   'uses' =>'CartController@updateCart',
   'as'   =>'update-cart-qty'
]);

Route::get('/checkout',[
   'uses' =>'CheckoutController@index',
   'as'   =>'checkout'
]);
//View
Route::get('/registration',[
   'uses' =>'CheckoutController@userRegistration',
   'as'   =>'user-registration'
]);

Route::post('/account',[
   'uses' =>'CheckoutController@customerRegistration',
   'as'   =>'customer-registration'
]);

Route::get('/profile',[
   'uses' =>'CheckoutController@customerProfile',
   'as'   =>'customer-profile'
]);

Route::get('/login',[
   'uses' =>'CheckoutController@customerLogin',
   'as'   =>'customer-login'
]);

Route::post('/profile',[
   'uses' =>'CheckoutController@accountLogin',
   'as'   =>'account-login'
]);

Route::post('/customer/registration',[
   'uses' =>'CheckoutController@customerSignUp',
   'as'   =>'customer-sign-up'
]);

//shipping blade
Route::get('/checkout/shipping',[
   'uses' =>'CheckoutController@shippingForm',
   'as'   =>'checkout-shipping'
]);

Route::post('/shipping/save',[
   'uses' =>'CheckoutController@saveShippingInfo',
   'as'   =>'new-shipping'
]);

Route::get('/checkout/payment',[
   'uses' =>'CheckoutController@paymentForm',
   'as'   =>'order-payment'
]);

Route::post('/confirm/order',[
   'uses' =>'CheckoutController@placedOrder',
   'as'   =>'placed-order'
]);

Route::get('/complete/order',[
   'uses' =>'CheckoutController@completedOrder',
   'as'   =>'order-completed'
]);

