<?php
/**
 * Created by PhpStorm.
 * User: Web App Develop - PH
 * Date: 3/16/2019
 * Time: 12:11 PM
 */

namespace app\classes;


class Student
{
    public function saveStudentInfo(){

    }
}