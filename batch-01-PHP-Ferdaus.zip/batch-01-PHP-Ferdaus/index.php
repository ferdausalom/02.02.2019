<?php

require_once 'vendor/autoload.php';
use App\Classes\News;

$newsInfo = new News();
$result = $newsInfo->showNewsInfo();

?>
<html>
<head>
    <title>News</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'inc/menu.php'; ?>
<div class="container" style="margin-top: 40px;">
    <div class="row">
        <div class="col-md-12 m-auto">
            <div class="card">
                <div class="card-body">
                    <table class="table table-responsive" border="2">
                        <tr class="bg-light">
                            <th>News Title</th>
                            <th>News Description</th>
                            <th>News Image</th>
                        </tr>

                        <?php $i=1;?>
                        <?php while ($news = mysqli_fetch_assoc($result)){?>
                            <tr>
                                <td><?php echo $news['news_title']?></td>
                                <td><?php echo $news['news_description']?></td>
                                <td><img src="project-bitm/<?php echo $news['news_image']?>" height="100" width="100"/> </td>
                            </tr>
                        <?php }?>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
