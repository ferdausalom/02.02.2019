<?php
/**
 * Created by PhpStorm.
 * User: Web App Develop - PH
 * Date: 3/18/2019
 * Time: 9:57 AM
 */

namespace App\Classes;


class Student
{
    public function saveStudentInfo(){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "INSERT INTO demos(name, email, mobile) VALUES ('$_POST[name]','$_POST[email]','$_POST[mobile]')";

        if (mysqli_query($link,$sql)){
            $message = "S info saved";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }

    public function viewStudentInfo(){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "SELECT * FROM demos";
        if (mysqli_query($link,$sql)){
            $result = mysqli_query($link,$sql);
            return $result;
            $message = "S info saved";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }

    public function editStudentInfo($id){
        $link = mysqli_connect('localhost','root','','demo');

        $sql = "SELECT * FROM demos WHERE id= '$id'";
        if (mysqli_query($link,$sql)){
            $result = mysqli_query($link,$sql);
            return $result;
            $message = "S info edited";
            return $message;
        }else{
            "Query problem".mysqli_connect_error($link);
        }
    }
}