<?php

require_once "vendor/autoload.php";
use App\Classes\Student;
$id = $_GET['id'];
$student = new Student();
$result = $student->editStudentInfo($id);

?>

<table border="1" width="500">
    <tr>
        <td><a href="addStudent.php">Add</a> </td>
        <td> <a href="viewStudent.php">View</a></td>
    </tr>
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>mobile</th>
        <th>Action</th>
    </tr>
    <?php while ($student = mysqli_fetch_assoc($result)){?>
        <tr>
            <td><input name="name" value="<?php echo $student['name'];?>"></td>
            <td><input name="email" value="<?php echo $student['email'];?>"></td>
            <td><input name="mobile" value="<?php echo $student['mobile'];?>"></td>
            <td><input name="btn" type="submit" value="Update"></td>
        </tr>
    <?php }?>
</table>
