<?php
/**
 * Created by PhpStorm.
 * User: Web App Develop - PH
 * Date: 3/13/2019
 * Time: 9:49 AM
 */

class ShowData
{
    public function tableData(){
        if (isset($_POST['btn']))
        {
            $Number1 = $_POST['Number1'];
            $Number2 = $_POST['Number2'];
            $Number3 = $_POST['Number3'];
            $Number4 = $_POST['Number4'];
            $Number5 = $_POST['Number5'];

            $result = $Number1+$Number2+$Number3+$Number4+$Number5;
            return $result;

        }
    }
}