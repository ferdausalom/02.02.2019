<?php
    require "./ShowData.php";
    $demo = new ShowData();
    $result = $demo->tableData();

    $Number1 = $_POST['Number1'];
    $Number2 = $_POST['Number2'];
    $Number3 = $_POST['Number3'];
    $Number4 = $_POST['Number4'];
    $Number5 = $_POST['Number5'];
?>

<form action="" method="post">
    <table>
        <tr>
            <td>First Number</td>
            <td><input type="text" name="Number1"></td>
        </tr>
        <tr>
            <td>Second Number</td>
            <td><input type="text" name="Number2"></td>
        </tr>

        <tr>
            <td>Third Number</td>
            <td><input type="text" name="Number3"></td>
        </tr>
        <tr>
            <td>Fourth Number</td>
            <td><input type="text" name="Number4"></td>
        </tr>
        <tr>
            <td>Fifth Number</td>
            <td><input type="text" name="Number5"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn" value="Submit"></td>
        </tr>
    </table>

</form>

    <hr/>

    <table width="400" hight="400" border="2" cellpadding="5" cellspacing="5">
        <tr>
            <th>1st</th>
            <th>2nd</th>
            <th>3rd</th>
            <th>4th</th>
            <th>5th</th>
            <th>Result</th>
        </tr>
        <tr>
            <td><input type="text" name="one" value="<?php echo $Number1; ?>"></td>
            <td><input type="text" name="two" value="<?php echo $Number2; ?>"></td>
            <td><input type="text" name="three" value="<?php echo $Number3; ?>"></td>
            <td><input type="text" name="four" value="<?php echo $Number4; ?>"></td>
            <td><input type="text" name="five" value="<?php echo $Number5; ?>"></td>
            <td><input type="text" name="five" value="<?php echo $result; ?>"></td>
        </tr>
    </table>