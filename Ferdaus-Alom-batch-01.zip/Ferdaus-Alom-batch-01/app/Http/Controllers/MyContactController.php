<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MyContactController extends Controller
{
    public function myContact(){
        return view('front-end.layouts.contact');
    }
}
