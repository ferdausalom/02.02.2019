<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ElementsController extends Controller
{
    public function elements(){
        return view('front-end.layouts.elements');
    }
}
