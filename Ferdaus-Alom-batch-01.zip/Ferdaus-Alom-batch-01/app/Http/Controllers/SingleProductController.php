<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SingleProductController extends Controller
{
    public function productDetails(){
        return view('front-end.layouts.single-product');
    }
}
