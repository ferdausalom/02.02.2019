<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BlogSingleController extends Controller
{
    public function blogSingle(){
        return view('front-end.layouts.blog-single');
    }
}
