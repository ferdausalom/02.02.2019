<?php

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/',[
   'uses' =>'HomePageController@homePage',
   'as'   =>'/'
]);

Route::get('/category',[
   'uses' =>'CategoryController@categoryPage',
   'as'   =>'new-category'
]);

Route::get('/product-details',[
   'uses' =>'SingleProductController@productDetails',
   'as'   =>'details-product'
]);

Route::get('/checkout',[
   'uses' =>'checkoutController@checkout',
   'as'   =>'check-out'
]);

Route::get('/cart',[
   'uses' =>'CartController@cart',
   'as'   =>'cart-page'
]);

Route::get('/confirmation',[
   'uses' =>'ConfirmationController@confirmation',
   'as'   =>'confirmation-page'
]);

Route::get('/blog',[
   'uses' =>'BlogController@blog',
   'as'   =>'blog-page'
]);

Route::get('/single-blog',[
   'uses' =>'BlogSingleController@blogSingle',
   'as'   =>'blog-single'
]);

Route::get('/login',[
   'uses' =>'LoginController@login',
   'as'   =>'login'
]);

Route::get('/tracking',[
   'uses' =>'TrackingController@tracking',
   'as'   =>'your-tracking'
]);

Route::get('/elements',[
   'uses' =>'ElementsController@elements',
   'as'   =>'elements'
]);

Route::get('/contact',[
   'uses' =>'MyContactController@myContact',
   'as'   =>'my-contact'
]);
