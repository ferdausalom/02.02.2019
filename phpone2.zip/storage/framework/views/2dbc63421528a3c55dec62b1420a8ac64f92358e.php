<?php $__env->startSection('title','Arrange Category'); ?>
<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-heading">
                    <h4 class="text-center text-success"><?php echo e(Session::get('message')); ?></h4>
                </div>
                <div class="panel-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>Sl No.</th>
                            <th>Product Name</th>
                            <th>Brand Name</th>
                            <th>Category Name</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Product Short Description</th>
                            <th>Product Image</th>
                            <th>Product Status</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->brand_name); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->product_price); ?></td>
                                <td><?php echo e($product->product_quantity); ?></td>
                                <td><?php echo e($product->short_description); ?></td>
                                <td><img width="50" height="50" src="<?php echo e(asset($product->product_image)); ?>"/></td>
                                <td><?php echo e($product->publication_status==1?'published':'Unpublished'); ?></td>
                                <td>
                                    <?php if($product->publication_status==1): ?>
                                        <a href="<?php echo e(route('unpublised-category',['id'=>$product->id])); ?>" class="btn btn-info">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('publised-category',['id'=>$product->id])); ?>" class="btn btn-warning">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('edit-product',['id'=>$product->id])); ?>" class="btn btn-danger">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a onclick="return confirm('are you sure to delete?')" href="<?php echo e(route('delete-category',['id'=>$product->id])); ?>" class="btn btn-danger">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHPExam\FerdausAlom\phpone\resources\views/admin/product/manage-product.blade.php ENDPATH**/ ?>