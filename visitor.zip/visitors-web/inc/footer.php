</section>
 <!-- footer -->
          <div class="footer clearfix">
            <div class="wthree-copyright">
              <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
            </div>
          </div>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<!-- //font-awesome icons -->
<script src="public/js/jquery.min.js"></script>
<!--<script src="public/js/raphael-min.js"></script>-->
<!--<script src="public/js/morris.js"></script>-->
<!--<script src="public/js/bootstrap.js"></script>-->
<!--<script src="public/js/jquery.dcjqaccordion.2.7.js"></script>-->
<!--<script src="public/js/scripts.js"></script>-->
<!--<script src="public/js/jquery.slimscroll.js"></script>-->
<!--<script src="public/js/jquery.nicescroll.js"></script>-->
<script src="http://localhost/PHPExam/FerdausAlom/visitors-web/public/js/addNewStudentform.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="public/js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->  

</body>
</html>