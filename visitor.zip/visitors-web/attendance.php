<?php include 'inc/header.php'?>
<?php include 'inc/sidebar.php'?>
<section id="main-content">
    <section class="wrapper">
        <div class="table-agile-info">
            <div class="panel-body">
                <table>
                    <form action="attendance_table.php" method="get">
                    <tr>
                        <td width="">
                            <div class="form-group">
                                <label for="class">Class:</label>
                                <select class="form-control" name="class">
                                    <option value="One">One</option>
                                    <option value="Two">Two</option>
                                    <option value="Three">Three</option>
                                </select>
                            </div>
                        </td>
                        <td width="">
                            <div class="form-group">
                                <label for="group">Group:</label>
                                <select class="form-control" name="grp">
                                    <option value="Science">Science</option>
                                    <option value="Business Studies">Business Studies</option>
                                    <option value="Arts">Arts</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                        </td>
                        <td width="">
                            <div class="form-group">
                                <label for="section">Section:</label>
                                <select class="form-control" name="section">
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                </select>
                            </div>
                        </td>
                        <td width="">
                            <div class="form-group">
                                <label for="date">Date:</label>
                                <input type="date" class="form-control text-center" name="curnt_date" value="<?php $curdate =date('Y-m-d'); echo $curdate;?>">
                            </div>
                        </td>
                        <td>
                            <div>
                                <label></label>
                                <input type="submit" class="btn btn-info" name="submit" value="Search"/>
                            </div>

                        </td>
                    </tr>
                    </form>
                </table>
            </div>
        </div>
    </section>
</section>
<?php include 'inc/footer.php'?>
