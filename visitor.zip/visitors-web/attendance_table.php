<?php include 'inc/header.php'?>
<?php include 'inc/sidebar.php'?>
<?php
require_once "vendor/autoload.php";
use App\Classes\Student;

if (isset($_GET['submit'])){
    $class = $_GET['class'];
    $grp= $_GET['grp'];
    $section = $_GET['section'];
    $curnt_date = $_GET['curnt_date'];
}
$student = new Student();
$relt = $student->getAllStudent($class,$grp,$section,$curnt_date);
?>
<section id="main-content">
<section class="wrapper">
    <div class="table-agile-info">


        <div class="well well-sm text-center">
            Dhaka Imperial College
        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <form action="" method="post">
                            <?php
                                if ($relt){
                                    while ($result = $relt->fetch_assoc()) {
                            ?>
                           <tr>
                               <td class="2">
                                   <div class="form-group">
                                       <label for="email">Class:</label>
                                       <input type="text" class="form-control text-center" value="<?php echo $result['class']?>">
                                   </div>
                               </td>
                               <td colspan="2">
                                   <div class="form-group">
                                       <label for="email">Section:</label>
                                       <input type="text" class="form-control text-center" value="<?php echo $result['section']?>">
                                   </div>
                               </td>
                               <td colspan="">
                                   <div class="form-group">
                                       <label for="date">Date:</label><br>

                                       <input type="text" class="form-control text-center" value="<?php $curdate =date('Y-m-d'); echo $curdate;?>">

                                   </div>
                               </td>
                           </tr>
                            <tr>
                                <th width="25%">Serial</th>
                                <th width="25%">Name</th>
                                <th width="25%">Roll</th>
                                <th width="25%">Attendance</th>
                                <th width="25%"></th>
                            </tr>
                            <tr>
                                <td>01</td>
                                <td><?php echo $result['std_name']?></td>
                                <td><?php echo $result['std_id']?></td>
                                <td>
                                    <input type="radio" name="attend" value="Present">Present
                                    <input type="radio" name="attend" value="Absent">Absent
                                </td>
                            </tr>






                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td colspan="2">
                                   <a class="btn btn-info" href="">View</a>
                                    <input class="btn btn-success pull-right" type="submit" name="btn" value="Submit">
                                </td>
                            </tr>
<?php }}?>
                        </form>
                    </table>
                </div>

            </div><!--panel-body close-->
        </div><!--panel-default close-->
    </div><!--table-agile-info close-->



</section>
</section>
<!--main content start-->
<!--<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Responsive Table
    </div>
    <div class="row w3-res-tb">
      <div class="col-sm-5 m-b-xs">
        <select class="input-sm form-control w-sm inline v-middle">
          <option value="0">Bulk action</option>
          <option value="1">Delete selected</option>
          <option value="2">Bulk edit</option>
          <option value="3">Export</option>
        </select>
        <button class="btn btn-sm btn-default">Apply</button>                
      </div>
      <div class="col-sm-4">
      </div>
      <div class="col-sm-3">
        <div class="input-group">
          <input type="text" class="input-sm form-control" placeholder="Search">
          <span class="input-group-btn">
            <button class="btn btn-sm btn-default" type="button">Go!</button>
          </span>
        </div>
      </div>
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
          <h2>Make a Table....</h2>
        <thead>

        </thead>
        <tbody>

        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      <div class="row">

        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
        </div>
        <div class="col-sm-7 text-right text-center-xs">
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>
</section>-->
<?php include 'inc/footer.php'?>