<?php
namespace App\Classes;
use App\Classes\Database;
class Student{

    public function getAllStudent($class,$grp,$section){
        $query = "SELECT * FROM one WHERE class = '$class' AND grp = '$grp' AND section = '$section'";

        if (mysqli_query(Connection::dbConnection(),$query)){
             return $result = mysqli_query(Connection::dbConnection(),$query);
        }else{
            die('Query Problem'.mysqli_error());
        }
}
public function submitnewStudent($data,$file){
        $stdname = mysqli_real_escape_string(Connection::dbConnection(),$data['stdname']);
        $fname = mysqli_real_escape_string(Connection::dbConnection(),$data['fname']);
        $mname = mysqli_real_escape_string(Connection::dbConnection(),$data['mname']);
        $roll = mysqli_real_escape_string(Connection::dbConnection(),$data['roll']);
        $password = mysqli_real_escape_string(Connection::dbConnection(),$data['password']);
        $stdclass = mysqli_real_escape_string(Connection::dbConnection(),$data['stdclass']);
        $grp = mysqli_real_escape_string(Connection::dbConnection(),$data['grp']);
        $section = mysqli_real_escape_string(Connection::dbConnection(),$data['section']);
        $dob = mysqli_real_escape_string(Connection::dbConnection(),$data['dob']);
        $gender = mysqli_real_escape_string(Connection::dbConnection(),$data['gender']);
        $blood = mysqli_real_escape_string(Connection::dbConnection(),$data['blood']);
        $present_add = mysqli_real_escape_string(Connection::dbConnection(),$data['present_add']);
        $permanent_add = mysqli_real_escape_string(Connection::dbConnection(),$data['permanent_add']);

            $img_name = $file['image']['name'];
            $temp_name = $file['image']['temp_name'];
            $store ="img/".$img_name;
            if (!empty($stdname) && !empty($fname) && !empty($mname) && !empty($roll) && !empty($password) && !empty($stdclass) && !empty($grp) && !empty($section) && !empty($dob) && !empty($gender) && !empty($blood) && !empty($present_add) && !empty($permanent_add) && !empty($img_name) ){
                move_uploaded_file($temp_name, "$store");
                $sql="INSERT INTO student_info(stdname,fname,mname,roll,stdclass,grp,stdsection,dob,gender,blood,password,present_add,permanent_add,image) VALUES ('$stdname','$fname','$mname','$roll','$stdclass','$grp','$section','$dob','$gender','$blood','$password','$present_add','$permanent_add','$store')";
                if (mysqli_query(Connection::dbConnection(),$sql)){
                     return $message ='Student information Inserted Successfully.';

                }else{
                    die('Query Problem'.mysqli_error());
                }

            }

        }
}
