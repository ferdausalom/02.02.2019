<?php include 'inc/header.php'?>
<?php include 'inc/sidebar.php'?>
<?php
include_once 'vendor/autoload.php';
use App\Classes\Student;
/*$_SERVER['REQUEST_METHOD'] == 'POST' &&*/
$student = new Student();
if (isset($_POST['submit'])) {
   $result =  $student->submitnewStudent($_POST,$_FILES);
}
?>
<section id="main-content">
    <section class="wrapper">
        <section class="panel panel-default">
            <div class="panel-heading">Student Registration Form</div>
            <div style="color: green" class="alert text-center">
                    <?php
                    if (isset($result)){
                        echo $result;
                    }
                    ?>
            </div>
        <div class="row">
            <div class="panel-body">
                <form id="form" action="" style="width: 700px;margin: auto" method="post" enctype="multipart/form-data">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Student Name</label>
                        <input type="text" class="form-control" id="stdname" name="stdname">
                        <div class="stdname-error error"></div>
                    </div>
                </div><!--student name-->
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Father Name</label>
                        <input type="text" class="form-control" id="fname" name="fname">
                        <div class="fname-error error"></div>
                    </div>
                </div><!--fathers name-->

                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Mother Name</label>
                        <input type="text" class="form-control" id="mname" name="mname">
                        <div class="mname-error error"></div>
                    </div>
                </div>
                    <!-- style="width: 697px;margin: auto" -->

                <div class="row" style="width: 697px;margin: auto">
                    <div class="col">
                        <div class="col-md-6 col-sm-6 col-12 mb-3">
                            <div class="form-group">
                                <label class="text-inverse" for="roll">Roll</label>
                                <input type="text" class="form-control" id="roll" name="roll">
                                <div class="invalid-feedback roll-error error"></div>
                            </div>
                        </div><!--roll-->
                    </div>

                    <div class="col">
                        <div class="col-md-6 col-sm-6 col-12 mb-3">
                            <div class="form-group">
                                <label class="text-inverse" for="validationCustom01">Class</label>
                                <select class="form-control" id="stdclass" name="stdclass">
                                    <option value="">----------------- Select Class -----------------</option>
                                    <option value="One">One</option>
                                    <option value="Two">Two</option>
                                    <option value="Three">Three</option>
                                </select>
                                <div class="invalid-feedback class-error error"></div>
                            </div>
                        </div><!--class-->
                    </div>

            </div><!-- roll-class row-->

                    <div class="row" style="width: 697px;margin: auto">
                        <div class="col">
            <div class="col-md-6 col-sm-6 col-12">
                <div class="form-group">
                    <label class="text-inverse" for="validationCustom01">Group</label>
                    <select class="form-control" name="grp" id="grp">
                        <option value="">----------------- Select Group -----------------</option>
                        <option value="Science">Science</option>
                        <option value="Business Studies">Business Studies</option>
                        <option value="Arts">Arts</option>
                        <option value="Others">Others</option>
                    </select>
                    <div class="invalid-feedback group-error error"></div>
                </div>
            </div>
                        </div>
                        <div class="col">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="section">Section</label>
                        <select class="form-control" name="section" id="section">
                            <option value="">----------------- Select Section -----------------</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="Others">Others</option>
                        </select>
                        <div class="invalid-feedback section-error error"></div>
                    </div>
                </div><!--section-->
                        </div>
                        </div>
                    <div class="row" style="width: 697px;margin: auto">
                        <div class="col">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Date of Birth</label>
                        <input type="date" class="form-control" id="dob" name="dob">
                        <div class="invalid-feedback birth-error error"></div>
                    </div>
                </div><!--date of birth-->
                        </div>
                        <div class="col">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Gender</label>
                        <select class="form-control" name="gender" id="gender">
                            <option value="">----------------- Select Gender -----------------</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Others">Others</option>
                        </select>
                        <div class="invalid-feedback gender-error error"></div>
                    </div>
                </div><!--gender-->
                        </div>
                        </div>
                    <div class="row" style="width: 697px;margin: auto">
                        <div class="col">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Blood Group</label>
                        <select class="form-control" name="blood" id="blood">
                            <option value="">----------------- Select Blood Group -----------------</option>
                            <option value="A+">A+</option>
                            <option value="O+">O+</option>
                            <option value="B+">B+</option>
                            <option value="AB+">AB+</option>
                            <option value="A-">A-</option>
                            <option value="O-">O-</option>
                            <option value="B-">B-</option>
                            <option value="AB-">AB-</option>
                            <option value="None">None</option>
                        </select>
                        <div class="invalid-feedback blood-error error"></div>
                    </div>
                </div><!--blood group-->
                </div>
                    <div class="col">
                <div class="col-md-6 col-sm-6 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Password</label>
                        <input type="text" class="form-control" id="password" name="password">
                        <div class="invalid-feedback password-error error"></div>
                    </div>
                </div><!--password-->
            </div>
        </div>
               <!-- <legend>Personal Information</legend>-->
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Present Address</label>
                        <input type="text" class="form-control" id="present_add" name="present_add">
                        <div class="invalid-feedback presentadd-error error"></div>
                    </div>
                </div><!--present address-->
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Permanent Address</label>
                        <input type="text" class="form-control" id="permanent_add" name="permanent_add">
                        <div class="invalid-feedback permanentadd-error error"></div>
                    </div>
                </div><!--permanent address-->

                <div class="col-md-12 col-sm-12 col-12">
                    <div class="form-group">
                        <label class="text-inverse" for="validationCustom01">Student Image</label>
                        <input type="file" class="form-control" id="image" name="image">
                        <div class="invalid-feedback image-error error"></div>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-12">
                    <!--<button type="button" id="submit" name="submit" class="btn btn-primary btn-md pull-right">Submit</button>-->
                    <input type="submit" name="submit" id="submit" class="btn btn-primary btn-md pull-right" value="Submit"/>
                </div>

                </form>
            </div>

        </div><!--row_1-->

        </section><!--panel-->
    </section><!--wrapper-->
    </section><!--main-content-->
</section>
<!-- footer -->
<div class="footer clearfix">
    <div class="wthree-copyright">
        <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
    </div>
</div>
<!-- / footer -->
</section>
<!--main content end-->
</section>
<!-- //font-awesome icons -->
<script src="public/js/jquery.min.js"></script>
<!--<script src="public/js/raphael-min.js"></script>-->
<!--<script src="public/js/morris.js"></script>-->
<!--<script src="public/js/bootstrap.js"></script>-->
<!--<script src="public/js/jquery.dcjqaccordion.2.7.js"></script>-->
<!--<script src="public/js/scripts.js"></script>-->
<!--<script src="public/js/jquery.slimscroll.js"></script>-->
<!--<script src="public/js/jquery.nicescroll.js"></script>-->
<script src="http://localhost/PHPExam/FerdausAlom/visitors-web/public/js/addNewStudentform.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="public/js/jquery.scrollTo.js"></script>
<!-- morris JavaScript -->

</body>
</html>
<?php //include 'inc/footer.php'?>
<script>
    setTimeout(function() {
        $('.alert').hide('slow');
    }, 3000);
</script>
