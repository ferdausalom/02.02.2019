$(document).ready(function () {


    var stdname ='';
    var fname ='';
    var mname ='';
    var roll = "";
    var password = "";
    var stdclass ="";
    var group ="";
    var birth ="";
    var gender ="";
    var blood ="";
    var section ="";
    var presntadd ="";
    var permanentadd ="";
    var image ="";
    var name_regx = /^[a-zA-Z ]+$/;
    var roll_regx = /^[0-9]*\D{4}$/;
    var password_regx = /^(?=.*\d)(?=.*[a-zA-Z])[0-9a-zA-Z]{8,}$/;

    // document.write(stdname);




    /* === Student Name Validation === */

    $("#stdname").focusout(function () {

        var store_name =$.trim($("#stdname").val());
        
        if (store_name.length==""){
            $(".stdname-error").html("Student name is required");
            $("#stdname").addClass("border-red");
            $("#stdname").removeClass("border-green");
            stdname='';
        }else if(name_regx.test(store_name)){
            $(".stdname-error").html("");
            $("#stdname").addClass("border-green");
            $("#stdname").removeClass("border-red");
            stdname= store_name;
        }else {
            $(".stdname-error").html("Use alphabets only");
            $("#stdname").addClass("border-red");
            $("#stdname").removeClass("border-green");
            stdname='';
        }
    });/* === close student name validation*/


    /* === Father Name Validation === */

    $("#fname").focusout(function () {
        var store_fname =$.trim($("#fname").val());

        if (store_fname.length==""){
            $(".fname-error").html("Father name is required");
            $("#fname").addClass("border-red");
            $("#fname").removeClass("border-green");
            fname='';
        }else if(name_regx.test(store_fname)){
            $(".fname-error").html("");
            $("#fname").addClass("border-green");
            $("#fname").removeClass("border-red");
            fname= store_fname;
        }else {
            $(".fname-error").html("Use alphabets only");
            $("#fname").addClass("border-red");
            $("#fname").removeClass("border-green");
            fname='';
        }
    });/* === close father name validation === */


    /* === Mother Name Validation === */

    $("#mname").focusout(function () {
        var store_mname =$.trim($("#mname").val());

        if (store_mname.length==""){
            $(".mname-error").html("Mother name is required");
            $("#mname").addClass("border-red");
            $("#mname").removeClass("border-green");
            mname='';
        }else if(name_regx.test(store_mname)){
            $(".mname-error").html("");
            $("#mname").addClass("border-green");
            $("#mname").removeClass("border-red");
            mname= store_mname;
        }else {
            $(".mname-error").html("Use alphabets only");
            $("#mname").addClass("border-red");
            $("#mname").removeClass("border-green");
            mname='';
        }
    });/* === close mother name validation === */

    /* === Roll Number Validation ===  */


    $("#roll").focusout(function(){
        var roll_store = $.trim($("#roll").val());
        if (roll_store.length == "") {
            $(".roll-error").html("Roll is required");
            $("#roll").addClass("border-red");
            $("#roll").removeClass("border-green");
            roll = "";
        }else if(roll_store.length<5){
            $(".roll-error").html("<div class='text-success'><i class='fa fa-check-circle'></i> success</div>");
            $("#roll").addClass("border-green");
            $("#roll").removeClass("border-red");
            roll = roll_store;
        }else{
            $(".roll-error").html("Length must be 4 digit and use only number type data");
            $("#roll").addClass("border-red");
            $("#roll").removeClass("border-green");
            roll = roll_store;
        }

    })/* === close roll number validation === */


    /* === Validation Password === */

    $("#password").focusout(function(){
        var password_store = $.trim($("#password").val());
        if (password_store.length == "") {
            $(".password-error").html("Password is required");
            $("#password").addClass("border-red");
            $("#password").removeClass("border-green");
            password = "";
        }else if(password_regx.test(password_store)){
            $(".password-error").html("<div class='text-success'><i class='fa fa-check-circle'></i> success</div>");
            $("#password").addClass("border-green");
            $("#password").removeClass("border-red");
            password = password_store;
        }else{
            $(".password-error").html("Use 8 or more characters with a mix of letters, numbers");
            $("#password").addClass("border-red");
            $("#password").removeClass("border-green");
            password = password_store;
        }

    })/* === Close Password validation === */


    /* === Validation class === */

    $("#stdclass").focusout(function(){
        var classoption = $(this).val();
        if (classoption.length == "") {
            $(".class-error").html("Class is requiredd");
            $("#stdclass").addClass("border-red");
            $("#stdclass").removeClass("border-green");
            stdclass = "";
        }else{
            $(".class-error").html("");
            $("#stdclass").addClass("border-green");
            $("#stdclass").removeClass("border-red");
            stdclass = classoption;
        }

    })/* === Close class validation === */

    /* === Validation Group === */

    $("#grp").focusout(function(){
        var grpoption = $(this).val();
        if (grpoption.length == "") {
            $(".group-error").html("Group is required");
            $("#grp").addClass("border-red");
            $("#grp").removeClass("border-green");
            group = "";
        }else{
            $(".group-error").html("");
            $("#grp").addClass("border-green");
            $("#grp").removeClass("border-red");
            group = grpoption;
        }

    })/* === Close class validation === */


    /* === Section Validation === */

    $("#section").focusout(function(){
        var secoption = $(this).val();
        if (secoption.length == "") {
            $(".section-error").html("Group is required");
            $("#section").addClass("border-red");
            $("#section").removeClass("border-green");
            section = "";
        }else{
            $(".section-error").html("");
            $("#section").addClass("border-green");
            $("#section").removeClass("border-red");
            section = secoption;
        }

    })/* === Close section validation === */


    /* === Date of Birth Validation === */

    $("#dob").focusout(function(){
        var store_birth = $(this).val();
        if (store_birth.length == "") {
            $(".birth-error").html("Birth day is required");
            $("#dob").addClass("border-red");
            $("#dob").removeClass("border-green");
            birth = "";
        }else{
            $(".birth-error").html("");
            $("#dob").addClass("border-green");
            $("#dob").removeClass("border-red");
            birth = store_birth;
        }

    })/* === Close Date of Birth validation === */

    /* === Gender Validation === */

    $("#gender").focusout(function(){
        var store_gender = $(this).val();
        if (store_gender.length == "") {
            $(".gender-error").html("Gender is required");
            $("#gender").addClass("border-red");
            $("#gender").removeClass("border-green");
            gender = "";
        }else{
            $(".gender-error").html("");
            $("#gender").addClass("border-green");
            $("#gender").removeClass("border-red");
            gender = store_gender;
        }

    })/* === Close Gender validation === */

    /* === Blood Validation === */

    $("#blood").focusout(function(){
        var store_blood = $(this).val();
        if (store_blood.length == "") {
            $(".blood-error").html("Blood is required");
            $("#blood").addClass("border-red");
            $("#blood").removeClass("border-green");
            blood = "";
        }else{
            $(".blood-error").html("");
            $("#blood").addClass("border-green");
            $("#blood").removeClass("border-red");
            blood = store_blood;
        }

    })/* === Close Gender validation === */

    /* === Present Address Validation === */

    $("#present_add").focusout(function () {
        var store_name =$.trim($("#present_add").val());

        if (store_name.length==""){
            $(".presentadd-error").html("present address is required");
            $("#present_add").addClass("border-red");
            $("#present_add").removeClass("border-green");
            presntadd='';
        }else{
            $(".presentadd-error").html("");
            $("#present_add").addClass("border-green");
            $("#present_add").removeClass("border-red");
            presntadd= store_name;
        }
    });/* === close present address validation*/

    /* === Permanent Address Validation === */

    $("#permanent_add").focusout(function () {
        var store_name =$.trim($("#permanent_add").val());

        if (store_name.length==""){
            $(".permanentadd-error").html("permanent address is required");
            $("#permanent_add").addClass("border-red");
            $("#permanent_add").removeClass("border-green");
            permanentadd='';
        }else{
            $(".permanentadd-error").html("");
            $("#permanent_add").addClass("border-green");
            $("#permanent_add").removeClass("border-red");
            permanentadd= store_name;
        }
    });/* === close Permanent address validation*/

    /* === Image Validation === */

    $("#image").focusout(function () {
        var store_name =$.trim($("#image").val());
        var ext = store_name.lastIndexOf(".") + 1;
        var extFile = store_name.substr(ext, store_name.length).toLowerCase();

        if (store_name.length==""){
            $(".image-error").html("image is required");
            $("#image").addClass("border-red");
            $("#image").removeClass("border-green");
            image='';
        }else if(extFile=="jpg" || extFile=="jpeg" || extFile=="png") {
            $(".image-error").html("");
            $("#image").addClass("border-green");
            $("#image").removeClass("border-red");
            image= store_name;

        }else{
            $(".image-error").html("Invalid Image Format! Image Format Must Be JPG, JPEG, PNG.");
            $("#image").addClass("border-red");
            $("#image").removeClass("border-green");
            image='';
        }
    });/* === close Image validation*/


    /* === submit the form === */
    $("#form").on('submit',function(e){
        e.preventDefault();
        if (stdname.length == "") {
            $(".stdname-error").html("");
            $("#stdname").addClass("border-red");
            $("#stdname").removeClass("border-green");
            stdname='';
        }
         if(fname.length == ""){
            $(".fname-error").html("");
            $("#fname").addClass("border-red");
            $("#fname").removeClass("border-green");
            fname='';
        }
        if(mname.length == ""){
            $(".mname-error").html("");
            $("#mname").addClass("border-red");
            $("#mname").removeClass("border-green");
            mname='';
        }
        if(roll.length == ""){
            $(".roll-error").html("");
            $("#roll").addClass("border-red");
            $("#roll").removeClass("border-green");
            mname='';
        }
        if (birth.length == "") {
            $(".birth-error").html("");
            $("#dob").addClass("border-red");
            $("#dob").removeClass("border-green");
            birth = "";
        }
        if (gender.length == "") {
            $(".gender-error").html("");
            $("#gender").addClass("border-red");
            $("#gender").removeClass("border-green");
            gender = "";
        }
        if (password.length == "") {
            $(".password-error").html("");
            $("#password").addClass("border-red");
            $("#password").removeClass("border-green");
            password = "";
        }
        if (stdclass.length == "") {
            $(".class-error").html("");
            $("#stdclass").addClass("border-red");
            $("#stdclass").removeClass("border-green");
            password = "";
        }
        if (group.length == "") {
            $(".group-error").html("");
            $("#grp").addClass("border-red");
            $("#grp").removeClass("border-green");
            group = "";
        }
        if (section.length == "") {
            $(".section-error").html("");
            $("#stdsection").addClass("border-red");
            $("#stdsection").removeClass("border-green");
            section = "";
        }
        if (blood.length == "") {
            $(".blood-error").html("");
            $("#blood").addClass("border-red");
            $("#blood").removeClass("border-green");
            blood = "";
        }
        if (presntadd.length == "") {
            $(".presentadd-error").html("");
            $("#present_add").addClass("border-red");
            $("#present_add").removeClass("border-green");
            presntadd = "";
        }
        if (permanentadd.length == "") {
            $(".permanentadd-error").html("");
            $("#permanent_add").addClass("border-red");
            $("#permanent_add").removeClass("border-green");
            permanentadd = "";
        }
        if (image.length == "") {
            $(".image-error").html("");
            $("#image").addClass("border-red");
            $("#image").removeClass("border-green");
            image = "";
        }

    })

});