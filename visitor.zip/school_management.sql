-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2019 at 07:51 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `one`
--

CREATE TABLE `one` (
  `sl` int(11) NOT NULL,
  `std_id` int(20) NOT NULL,
  `std_name` varchar(40) NOT NULL,
  `class` varchar(10) NOT NULL,
  `section` varchar(7) NOT NULL,
  `grp` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `image` varchar(255) NOT NULL,
  `attendance` varchar(10) NOT NULL,
  `curnt_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `one`
--

INSERT INTO `one` (`sl`, `std_id`, `std_name`, `class`, `section`, `grp`, `dob`, `fname`, `mname`, `image`, `attendance`, `curnt_date`) VALUES
(1, 1002, 'Tarek Hossain', 'One', 'A', 'Others', '2019-03-05', 'Motaha Hossain', 'Nasrin Akter', '', 'Present', '2019-03-03');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(11) NOT NULL,
  `stdname` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `roll` int(100) NOT NULL,
  `stdclass` varchar(15) NOT NULL,
  `grp` varchar(15) NOT NULL,
  `stdsection` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(11) NOT NULL,
  `blood` varchar(11) NOT NULL,
  `password` text NOT NULL,
  `present_add` text NOT NULL,
  `permanent_add` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `one`
--
ALTER TABLE `one`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `one`
--
ALTER TABLE `one`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
