<?php
/*Route::get('/', function () {
    return view('welcome');
});*/

/*Route::get('/home',[
    'uses'=>'FirstController@index',
    'as'=>'/'
]);*/
Route::get('/',[
    'uses' => 'FirstController@index',
    'as' => '/'
]);
Route::get('/about',[
    'uses' => 'FirstController@about',
    'as' => '/about'
]);
Route::get('/bakeryProduct',[
    'uses' => 'FirstController@bakeryProduct',
    'as'   => '/bakeryProduct'
]);
Route::get('/kitchenDiningProduct',[
    'uses' => 'FirstController@kitchenDiningProduct',
    'as'   => '/kitchenDiningProduct'
]);
Route::get('/faqs',[
    'uses' => 'FirstController@faqs',
    'as'   => '/faqs'
]);
Route::get('/contact',[
    'uses' => 'FirstController@contact',
    'as'   => '/contact'
]);

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
