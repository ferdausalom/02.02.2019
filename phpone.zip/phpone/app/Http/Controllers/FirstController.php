<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FirstController extends Controller
{
    public function index(){
        return view('forntEnd.home.home');
    }
    public function about(){
        return view('forntEnd.about.about');
    }
    public function bakeryProduct(){
        return view('forntEnd.kitchen.bakeryProduct');
    }
    public function kitchenDiningProduct(){
        return view('forntEnd.household.kitchenDiningProduct');
    }
    public function faqs(){
        return view('forntEnd.faqs.faqs');
    }
    public function contact(){
        return view('forntEnd.contact.contact');
    }
}
