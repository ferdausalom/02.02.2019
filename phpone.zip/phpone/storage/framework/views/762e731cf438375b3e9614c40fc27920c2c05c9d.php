<a href="<?php echo e(route('/')); ?>">BITM</a>
<a href="<?php echo e(route('/about')); ?>">ABOUT</a>

<div>
    <h3><?php echo e($name); ?></h3>
    <form action="<?php echo e(route('my-form')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name">
        <input type="submit" value="Submit">

    </form>
</div>
<?php /* C:\xampp\htdocs\bitm_batch1\resources\views/home.blade.php */ ?>